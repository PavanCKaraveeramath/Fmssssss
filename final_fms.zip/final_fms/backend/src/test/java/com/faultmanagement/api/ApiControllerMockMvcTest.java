package com.faultmanagement.api;

import com.faultmanagement.dto.AlarmDTO;
import com.faultmanagement.dto.ApiResponse;
import com.faultmanagement.dto.DeviceDTO;
import com.faultmanagement.dto.LoginResponse;
import com.faultmanagement.dto.PageResponse;
import com.faultmanagement.dto.ReportResponse;
import com.faultmanagement.dto.UserDTO;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.AlarmStatus;
import com.faultmanagement.entity.Roles;
import com.faultmanagement.entity.Status;
import com.faultmanagement.exception.FaultManagementException;
import com.faultmanagement.service.AlarmService;
import com.faultmanagement.service.DeviceService;
import com.faultmanagement.service.ReportService;
import com.faultmanagement.service.UserAdminService;
import com.faultmanagement.service.UserLoginService;
import com.faultmanagement.utility.GlobalExceptionHandler;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = {
        AuthController.class,
        AdminUserController.class,
        DeviceController.class,
        FaultController.class,
        ReportController.class
})
@AutoConfigureMockMvc(addFilters = false)
@Import(GlobalExceptionHandler.class)
class ApiControllerMockMvcTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private UserLoginService userLoginService;

    @MockitoBean
    private UserAdminService userAdminService;

    @MockitoBean
    private DeviceService deviceService;

    @MockitoBean
    private AlarmService alarmService;

    @MockitoBean
    private ReportService reportService;

    @Test
    void loginWithValidCredentialsReturnsToken() throws Exception {
        when(userLoginService.login(any())).thenReturn(LoginResponse.builder()
                .message("Welcome, operator!")
                .token("test-token")
                .username("operator")
                .role(Roles.OPERATOR)
                .build());

        mockMvc.perform(post("/api/auth/login")
                        .contentType("application/json")
                        .content("""
                                {"username":"operator","password":"Operator123!"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("operator"))
                .andExpect(jsonPath("$.role").value("OPERATOR"))
                .andExpect(jsonPath("$.token").value("test-token"));
    }

    @Test
    void loginWithWrongPasswordReturnsUnauthorized() throws Exception {
        when(userLoginService.login(any())).thenThrow(
                FaultManagementException.unauthorized("The username or password is incorrect."));

        mockMvc.perform(post("/api/auth/login")
                        .contentType("application/json")
                        .content("""
                                {"username":"operator","password":"wrong"}
                                """))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("The username or password is incorrect."));
    }

    @Test
    void loginWithoutPasswordReturnsValidationError() throws Exception {
        mockMvc.perform(post("/api/auth/login")
                        .contentType("application/json")
                        .content("""
                                {"username":"operator"}
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.password").value("Password is mandatory"));

        verify(userLoginService, never()).login(any());
    }

    @Test
    void changePasswordReturnsSuccess() throws Exception {
        when(userLoginService.changePassword(any()))
                .thenReturn(ApiResponse.of("Password changed successfully.", Map.of("strength", "Strong")));

        mockMvc.perform(post("/api/auth/change-password")
                        .contentType("application/json")
                        .content("""
                                {"username":"operator","currentPassword":"OldPass1!","newPassword":"NewPass2!"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Password changed successfully."));
    }

    @Test
    void getForgotPasswordQuestionReturnsQuestion() throws Exception {
        when(userLoginService.getSecurityQuestion("operator")).thenReturn("First pet?");

        mockMvc.perform(post("/api/auth/forgot-password/get-question")
                        .contentType("application/json")
                        .content("""
                                {"username":"operator"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.username").value("operator"))
                .andExpect(jsonPath("$.data.securityQuestion").value("First pet?"));
    }

    @Test
    void resetForgottenPasswordReturnsSuccess() throws Exception {
        mockMvc.perform(post("/api/auth/forgot-password/reset")
                        .contentType("application/json")
                        .content("""
                                {"username":"operator","securityAnswer":"atlas","newPassword":"NewPass2!"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message")
                        .value("Your password was reset successfully. You can now sign in with the new password."));

        verify(userLoginService).resetPassword(any());
    }

    @Test
    void listUsersReturnsPage() throws Exception {
        UserDTO user = user(25L, "operator", Roles.OPERATOR);
        when(userAdminService.listUsers(PageRequest.of(0, 10))).thenReturn(
                new PageResponse<>("There is 1 matching result.", List.of(user), 0, 10, 1, 1));

        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].username").value("operator"))
                .andExpect(jsonPath("$.totalElements").value(1));
    }

    @Test
    void addUserReturnsCreated() throws Exception {
        when(userAdminService.addUser(any())).thenReturn(user(25L, "new.operator", Roles.OPERATOR));

        mockMvc.perform(post("/api/admin/users")
                        .contentType("application/json")
                        .content("""
                                {"username":"new.operator","password":"StrongPass1!","role":"OPERATOR",
                                "securityQuestion":"First pet?","securityAnswer":"atlas"}
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.username").value("new.operator"))
                .andExpect(jsonPath("$.data.role").value("OPERATOR"));
    }

    @Test
    void addUserWithUnknownRoleReturnsBadRequest() throws Exception {
        mockMvc.perform(post("/api/admin/users")
                        .contentType("application/json")
                        .content("""
                                {"username":"new.operator","password":"StrongPass1!","role":"GUEST",
                                "securityQuestion":"First pet?","securityAnswer":"atlas"}
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message")
                        .value("Invalid value 'GUEST' for role. Allowed values: [ADMIN, OPERATOR, MANAGER]"));

        verify(userAdminService, never()).addUser(any());
    }

    @Test
    void changeUserRoleReturnsSuccess() throws Exception {
        when(userAdminService.changeRole("operator", Roles.MANAGER))
                .thenReturn(user(25L, "operator", Roles.MANAGER));

        mockMvc.perform(put("/api/admin/users/operator/role")
                        .contentType("application/json")
                        .content("""
                                {"role":"MANAGER"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.role").value("MANAGER"));
    }

    @Test
    void deactivateUserReturnsSuccess() throws Exception {
        when(userAdminService.deactivate(25L)).thenReturn(user(25L, "operator", Roles.OPERATOR));

        mockMvc.perform(delete("/api/admin/users/25"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message")
                        .value("The user was deactivated successfully and can no longer sign in."));
    }

    @Test
    void listDevicesReturnsPage() throws Exception {
        DeviceDTO device = device(12L, "RTR-12", "10.12.0.1");
        when(deviceService.listActive(any())).thenReturn(
                new PageResponse<>("There is 1 matching result.", List.of(device), 0, 10, 1, 1));

        mockMvc.perform(get("/api/operator/devices"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].serialNumber").value("RTR-12"))
                .andExpect(jsonPath("$.totalElements").value(1));
    }

    @Test
    void addDeviceReturnsCreated() throws Exception {
        when(deviceService.addDevice(any())).thenReturn(device(12L, "RTR-12", "10.12.0.1"));

        mockMvc.perform(post("/api/operator/devices")
                        .contentType("application/json")
                        .content("""
                                {"serialNumber":"RTR-12","ipAddress":"10.12.0.1","deviceType":"Router"}
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.serialNumber").value("RTR-12"))
                .andExpect(jsonPath("$.data.deviceState").value("Activated"));
    }

    @Test
    void addDeviceWithInvalidIpReturnsBadRequest() throws Exception {
        mockMvc.perform(post("/api/operator/devices")
                        .contentType("application/json")
                        .content("""
                                {"serialNumber":"RTR-12","ipAddress":"999.10.0.1","deviceType":"Router"}
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.ipAddress").exists());

        verify(deviceService, never()).addDevice(any());
    }

    @Test
    void updateDeviceIpReturnsSuccess() throws Exception {
        when(deviceService.updateIp("RTR-12", "10.12.0.2"))
                .thenReturn(device(12L, "RTR-12", "10.12.0.2"));

        mockMvc.perform(put("/api/operator/devices/RTR-12")
                        .contentType("application/json")
                        .content("""
                                {"ipAddress":"10.12.0.2"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.ipAddress").value("10.12.0.2"));
    }

    @Test
    void deactivateDeviceReturnsSuccess() throws Exception {
        mockMvc.perform(delete("/api/operator/devices/RTR-12"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message")
                        .value("The device was deactivated successfully and removed from the active device list."));

        verify(deviceService).deactivate("RTR-12");
    }

    @Test
    void listFaultsReturnsPage() throws Exception {
        AlarmDTO alarm = alarm(41L, "cbgpFsmStateChange", AlarmStatus.OPEN);
        when(alarmService.listActive(any(), any(), any(), any())).thenReturn(
                new PageResponse<>("There is 1 matching result.", List.of(alarm), 0, 10, 1, 1));

        mockMvc.perform(get("/api/manager/faults").param("severity", "CRITICAL"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].alarmName").value("cbgpFsmStateChange"))
                .andExpect(jsonPath("$.content[0].status").value("OPEN"))
                .andExpect(jsonPath("$.totalElements").value(1));
    }

    @Test
    void listFaultsWithInvalidSeverityReturnsBadRequest() throws Exception {
        when(alarmService.listActive(any(), any(), any(), any()))
                .thenThrow(FaultManagementException.badRequest("Invalid severity 'PURPLE'."));

        mockMvc.perform(get("/api/manager/faults").param("severity", "PURPLE"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Invalid severity 'PURPLE'."));
    }

    @Test
    void acknowledgeFaultReturnsSuccess() throws Exception {
        when(alarmService.acknowledge(List.of(41L)))
                .thenReturn(List.of(alarm(41L, "cbgpFsmStateChange", AlarmStatus.ACKNOWLEDGED)));

        mockMvc.perform(post("/api/manager/faults/acknowledge")
                        .contentType("application/json")
                        .content("""
                                {"id":41}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.updated").value(1))
                .andExpect(jsonPath("$.data.alarms[0].status").value("ACKNOWLEDGED"));
    }

    @Test
    void clearFaultReturnsSuccess() throws Exception {
        when(alarmService.clear(List.of(41L)))
                .thenReturn(List.of(alarm(41L, "cbgpFsmStateChange", AlarmStatus.CLEARED)));

        mockMvc.perform(post("/api/manager/faults/clear")
                        .contentType("application/json")
                        .content("""
                                {"id":41}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("The fault was cleared successfully."));
    }

    @Test
    void terminateFaultReturnsSuccess() throws Exception {
        when(alarmService.terminate(List.of(41L)))
                .thenReturn(List.of(alarm(41L, "cbgpFsmStateChange", AlarmStatus.TERMINATED)));

        mockMvc.perform(post("/api/manager/faults/terminate")
                        .contentType("application/json")
                        .content("""
                                {"id":41}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("The fault was terminated successfully."));
    }

    @Test
    void updateFaultNotesReturnsSuccess() throws Exception {
        when(alarmService.updateNotes(41L, "Checked"))
                .thenReturn(alarm(41L, "cbgpFsmStateChange", AlarmStatus.OPEN));

        mockMvc.perform(put("/api/manager/faults/41/notes")
                        .contentType("application/json")
                        .content("""
                                {"notes":"Checked"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("The fault notes were updated successfully."));
    }

    @Test
    void updateFaultNotesOverMaximumLengthReturnsBadRequest() throws Exception {
        String notes = "x".repeat(501);

        mockMvc.perform(put("/api/manager/faults/41/notes")
                        .contentType("application/json")
                        .content("{\"notes\":\"" + notes + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.notes").value("Notes must be at most 500 characters"));

        verify(alarmService, never()).updateNotes(eq(41L), any());
    }

    @Test
    void severityReportReturnsCounts() throws Exception {
        when(reportService.bySeverity()).thenReturn(
                new ReportResponse("BY_SEVERITY", 3, Map.of("CRITICAL", 1L, "MAJOR", 2L)));

        mockMvc.perform(get("/api/manager/reports/by-severity"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.report").value("BY_SEVERITY"))
                .andExpect(jsonPath("$.total").value(3))
                .andExpect(jsonPath("$.counts.CRITICAL").value(1));
    }

    @Test
    void statusReportReturnsCounts() throws Exception {
        when(reportService.byStatus()).thenReturn(
                new ReportResponse("BY_STATUS", 2, Map.of("OPEN", 1L, "CLEARED", 1L)));

        mockMvc.perform(get("/api/manager/reports/by-status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.report").value("BY_STATUS"))
                .andExpect(jsonPath("$.total").value(2))
                .andExpect(jsonPath("$.counts.OPEN").value(1));
    }

    private UserDTO user(Long id, String username, Roles role) {
        return UserDTO.builder()
                .id(id)
                .username(username)
                .role(role)
                .userState(Status.Activated)
                .build();
    }

    private DeviceDTO device(Long id, String serialNumber, String ipAddress) {
        return DeviceDTO.builder()
                .id(id)
                .serialNumber(serialNumber)
                .ipAddress(ipAddress)
                .deviceType("Router")
                .deviceState(Status.Activated)
                .build();
    }

    private AlarmDTO alarm(Long id, String name, AlarmStatus status) {
        return AlarmDTO.builder()
                .id(id)
                .alarmName(name)
                .serialNumber("RTR-12")
                .deviceIp("10.12.0.1")
                .severity(AlarmSeverity.CRITICAL)
                .status(status)
                .build();
    }
}
