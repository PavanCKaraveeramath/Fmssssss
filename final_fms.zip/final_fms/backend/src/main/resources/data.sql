-- Seed data (idempotent). Same demo accounts as the React frontend.
--   admin    / Admin123!     (security answer: blue)
--   operator / Operator123!  (security answer: atlas)
--   manager  / Manager123!   (security answer: rose)
-- Passwords are BCrypt hashes.

INSERT IGNORE INTO security_questions (question) VALUES
 ('What is your favorite color?'),
 ('What is the name of your first pet?'),
 ('What was the name of your first school?');

INSERT IGNORE INTO users (username, password, role, user_state, security_question, security_answer) VALUES
 ('admin',    '$2b$10$y02pG.HrsZ5Y6SwLYADul.BVDW0omh75iHersdkpfrquZWF5cz.fm',    'ADMIN',    'Activated', 'What is your favorite color?',           'blue'),
 ('operator', '$2b$10$rYEdtpoMcXaXc/QeS2hk..pP3ekKWl7YoZ3zG1bGSNv328Saf8tWq', 'OPERATOR', 'Activated', 'What is the name of your first pet?',    'atlas'),
 ('manager',  '$2b$10$ozx1SutgDr3E4VHrpSVITu2o3au58iWSfCYree6eRoYfavhIe.hoS',  'MANAGER',  'Activated', 'What was the name of your first school?', 'rose');

INSERT IGNORE INTO devices (serial_number, ip_address, device_type, device_state) VALUES
 ('RT123', '10.0.0.1', 'Router', 'Activated'),
 ('NS156', '10.0.0.2', 'Switch', 'Activated');

INSERT INTO alarms (
    alarm_name, device_ip, serial_number, severity, status, probable_cause,
    occurrence_count, first_time_detected, last_time_detected,  notes
)
SELECT seed.alarm_name, seed.device_ip, seed.serial_number, seed.severity, seed.status,
       seed.probable_cause, seed.occurrence_count, seed.first_time_detected,
       seed.last_time_detected, seed.notes
FROM (
    SELECT 'cbgpFsmStateChange' AS alarm_name, '10.0.0.1' AS device_ip, 'RT123' AS serial_number,
           'CRITICAL' AS severity, 'OPEN' AS status, 8 AS probable_cause, 3 AS occurrence_count,
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 15 MINUTE) * 1000 AS UNSIGNED) AS first_time_detected,
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 2 MINUTE) * 1000 AS UNSIGNED) AS last_time_detected,
           'BGP peer session repeatedly changed state.' AS notes
    UNION ALL
    SELECT 'cbgpPrefixThresholdExceeded', '10.0.0.2', 'NS156',
           'MAJOR', 'ACKNOWLEDGED', 10, 2,
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 30 MINUTE) * 1000 AS UNSIGNED),
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 10 MINUTE) * 1000 AS UNSIGNED),
           'BGP prefix count exceeded the configured threshold.'
    UNION ALL
    SELECT 'cbgpBackwardTransition', '10.0.0.1', 'RT123',
           'SEVERE', 'OPEN', 9, 1,
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 5 MINUTE) * 1000 AS UNSIGNED),
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 5 MINUTE) * 1000 AS UNSIGNED),
           'BGP peer moved to a lower FSM state.'
    UNION ALL
    SELECT 'cbgpPrefixThresholdClear', '10.0.0.2', 'NS156',
           'CLEAR', 'CLEARED', 11, 1,
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 60 MINUTE) * 1000 AS UNSIGNED),
           CAST(UNIX_TIMESTAMP(CURRENT_TIMESTAMP(3) - INTERVAL 45 MINUTE) * 1000 AS UNSIGNED),
           'BGP prefix count returned below the threshold.'
) AS seed
WHERE NOT EXISTS (
    SELECT 1
    FROM alarms existing
    WHERE existing.alarm_name = seed.alarm_name
      AND existing.device_ip = seed.device_ip
);
