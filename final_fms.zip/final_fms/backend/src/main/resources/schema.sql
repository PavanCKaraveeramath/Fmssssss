-- Fault Management Dashboard : MySQL 8 schema (idempotent).
-- Keep this database name aligned with the datasource default in application.properties.

CREATE DATABASE IF NOT EXISTS fault_management_dashboard;
USE fault_management_dashboard;

CREATE TABLE IF NOT EXISTS security_questions (
    id        BIGINT       PRIMARY KEY AUTO_INCREMENT,
    question  VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS users (
    id                BIGINT       PRIMARY KEY AUTO_INCREMENT,
    username          VARCHAR(100) NOT NULL UNIQUE,
    password          VARCHAR(255) NOT NULL,                       -- BCrypt hash
    role              VARCHAR(20)  NOT NULL,                       -- ADMIN | OPERATOR | MANAGER
    user_state        VARCHAR(20)  NOT NULL DEFAULT 'Activated',   -- Activated | Deactivated
    security_question VARCHAR(255) NULL,
    security_answer   VARCHAR(255) NULL,
    CONSTRAINT chk_users_role  CHECK (role IN ('ADMIN','OPERATOR','MANAGER')),
    CONSTRAINT chk_users_state CHECK (user_state IN ('Activated','Deactivated'))
);

CREATE TABLE IF NOT EXISTS devices (
    id            BIGINT       PRIMARY KEY AUTO_INCREMENT,
    serial_number VARCHAR(100) NOT NULL UNIQUE,
    ip_address    VARCHAR(45)  NOT NULL UNIQUE,
    device_type   VARCHAR(100) NOT NULL,                           -- Router | Switch | Hub
    device_state  VARCHAR(20)  NOT NULL DEFAULT 'Activated',       -- Activated | Deactivated
    CONSTRAINT chk_devices_state CHECK (device_state IN ('Activated','Deactivated'))
);

CREATE TABLE IF NOT EXISTS alarms (
    id                   BIGINT       PRIMARY KEY AUTO_INCREMENT,
    alarm_name           VARCHAR(255) NOT NULL,
    device_ip            VARCHAR(45)  NOT NULL,
    serial_number        VARCHAR(100) NOT NULL,
    severity             VARCHAR(20)  NOT NULL,                    -- CLEAR|WARNING|MAJOR|SEVERE|CRITICAL
    status               VARCHAR(20)  NOT NULL DEFAULT 'OPEN',     -- OPEN|ACKNOWLEDGED|CLEARED|TERMINATED
    probable_cause       INT          NULL,
    occurrence_count     INT          NULL,
    first_time_detected  BIGINT       NULL,
    last_time_detected   BIGINT       NULL,
    notes                VARCHAR(500) NULL,
    INDEX idx_alarms_status (status),
    INDEX idx_alarms_severity (severity),
    INDEX idx_alarms_device_ip (device_ip),
    INDEX idx_alarms_serial (serial_number),
    CONSTRAINT chk_alarms_sev CHECK (severity IN ('CLEAR','WARNING','MAJOR','SEVERE','CRITICAL')),
    CONSTRAINT chk_alarms_status CHECK (status IN ('OPEN','ACKNOWLEDGED','CLEARED','TERMINATED'))
);
