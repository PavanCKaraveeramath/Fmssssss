package com.faultmanagement.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ForgotQuestionRequest {

    @NotBlank(message = "{validation.username.required}")
    private String username;
}
