package com.faultmanagement.utility;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;

public final class PageRequests {

    public static final int MAX_PAGE_SIZE = 100;

    private PageRequests() {
    }

    public static @NonNull Pageable of(Pageable requested, @NonNull Sort sort) {
        int page = Math.max(requested.getPageNumber(), 0);
        int size = requested.getPageSize() < 1 ? 10 : Math.min(requested.getPageSize(), MAX_PAGE_SIZE);
        return PageRequest.of(page, size, sort);
    }
}
