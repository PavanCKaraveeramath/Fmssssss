package com.faultmanagement.simulator;

import com.faultmanagement.dto.xml.AlarmInfoXml;
import com.faultmanagement.dto.xml.AlarmListXml;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.Device;
import com.faultmanagement.entity.Status;
import com.faultmanagement.repository.DeviceRepository;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

@Component
@Slf4j
public class TrapSimulator {

    private record Trap(String name, int probableCause, String text) {
    }

    private static final List<Trap> TRAPS = List.of(
            new Trap("cbgpFsmStateChange", 8, "BGP peer FSM state changed"),
            new Trap("cbgpBackwardTransition", 9, "BGP peer moved to a lower FSM state"),
            new Trap("cbgpPrefixThresholdExceeded", 10, "BGP prefix count exceeded the threshold"),
            new Trap("cbgpPrefixThresholdClear", 11, "BGP prefix count dropped below the threshold"));

    private static final List<AlarmSeverity> SEVERITIES =
            List.of(AlarmSeverity.CRITICAL, AlarmSeverity.SEVERE, AlarmSeverity.MAJOR, AlarmSeverity.WARNING);

    private final DeviceRepository deviceRepository;
    private final Path inputDir;
    private final XmlMapper xmlMapper = new XmlMapper();

    public TrapSimulator(DeviceRepository deviceRepository, @Value("${fm.simulator.input-dir}") String inputDir) {
        this.deviceRepository = deviceRepository;
        this.inputDir = Path.of(inputDir);
    }

    @Scheduled(fixedRateString = "${fm.simulator.interval-ms:60000}",
            initialDelayString = "${fm.simulator.initial-delay-ms:5000}")
    public void generateTraps() {
        try {
            List<Device> devices = deviceRepository.findByDeviceState(Status.Activated);
            if (devices.isEmpty()) {
                log.info("Simulator: no active devices, nothing generated");
                return;
            }
            AlarmListXml list = new AlarmListXml();
            devices.forEach(d -> list.getAlarms().add(buildAlarm(d)));
            write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                    + xmlMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list));
            log.info("Simulator generated {} trap(s)", devices.size());
        } catch (Exception ex) {
            log.error("Trap simulation failed", ex);
        }
    }

    private AlarmInfoXml buildAlarm(Device device) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        Trap trap = TRAPS.get(random.nextInt(TRAPS.size()));
        long now = System.currentTimeMillis();

        AlarmInfoXml x = new AlarmInfoXml();
        String severity = SEVERITIES.get(random.nextInt(SEVERITIES.size())).name().toLowerCase(Locale.ROOT);
        x.setSeverity(severity);
        x.setPreviousSeverity("indeterminate");
        x.setOriginalSeverity(severity);
        x.setProbableCause(trap.probableCause());
        x.setAlarmName(trap.name());
        x.setIsAcknowledged(false);
        x.setFirstTimeDetected(now);
        x.setLastTimeDetected(now);
        x.setNumberOfOccurences(1);
        x.setIsServiceAffecting(false);
        x.setAdditionalText(trap.text());
        x.setNodeId(device.getIpAddress());
        x.setNodeName(device.getSerialNumber());
        x.setAffectedObjectDisplayedName("Port 1/1/32");
        x.setApplicationDomain("Physical Equipment");
        x.setDisplayedClass("PhysicalPort");
        return x;
    }

    /** Written as .tmp then renamed, so ingestion never reads a half-written file. */
    private void write(String xml) throws IOException {
        Files.createDirectories(inputDir);
        String base = "alarms_" + System.currentTimeMillis();
        Path tmp = inputDir.resolve(base + ".tmp");
        Path target = inputDir.resolve(base + ".xml");
        Files.writeString(tmp, xml, StandardCharsets.UTF_8);
        try {
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(tmp, target);
        }
    }
}
