package com.faultmanagement.dto;

import com.faultmanagement.entity.Alarm;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.AlarmStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class AlarmDTO {

    private final Long id;
    private final String alarmName;
    private final String deviceIp;
    private final String serialNumber;
    private final String deviceType;
    private final AlarmSeverity severity;
    private final AlarmStatus status;
    private final Integer probableCause;
    private final Integer occurrenceCount;
    private final Long firstTimeDetected;
    private final Long lastTimeDetected;
    private final String notes;

    public static AlarmDTO from(Alarm alarm, String deviceType) {
        return AlarmDTO.builder()
                .id(alarm.getId())
                .alarmName(alarm.getAlarmName())
                .deviceIp(alarm.getDeviceIp())
                .serialNumber(alarm.getSerialNumber())
                .deviceType(deviceType)
                .severity(alarm.getSeverity())
                .status(alarm.getStatus())
                .probableCause(alarm.getProbableCause())
                .occurrenceCount(alarm.getOccurrenceCount())
                .firstTimeDetected(alarm.getFirstTimeDetected())
                .lastTimeDetected(alarm.getLastTimeDetected())
                .notes(alarm.getNotes())
                .build();
    }
}
