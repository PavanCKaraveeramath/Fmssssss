package com.faultmanagement.service;

import com.faultmanagement.dto.CreateUserRequest;
import com.faultmanagement.dto.PageResponse;
import com.faultmanagement.dto.UserDTO;
import com.faultmanagement.entity.Roles;
import com.faultmanagement.entity.Status;
import com.faultmanagement.entity.User;
import com.faultmanagement.exception.DuplicateResourceException;
import com.faultmanagement.exception.FaultManagementException;
import com.faultmanagement.repository.UserRepository;
import com.faultmanagement.utility.PageRequests;
import com.faultmanagement.utility.PasswordPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Service
public class UserAdminServiceImpl implements UserAdminService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public PageResponse<UserDTO> listUsers(@NonNull Pageable pageable) {
        return PageResponse.from(
                userRepository.findAll(PageRequests.of(pageable, Sort.by(Sort.Direction.ASC, "id"))), UserDTO::from);
    }

    @Transactional
    public UserDTO addUser(CreateUserRequest request) {
        String username = request.getUsername().trim();
        if (userRepository.existsByUsername(username)) {
            throw new DuplicateResourceException(
                    "That username is already in use. Choose a different username and try again.");
        }
        if (!PasswordPolicy.isAcceptable(request.getPassword())) {
            throw FaultManagementException.badRequest(PasswordPolicy.REQUIREMENT_MESSAGE);
        }
        User user = Objects.requireNonNull(User.builder()
                .username(username)
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .userState(Status.Activated)
                .securityQuestion(request.getSecurityQuestion())
                .securityAnswer(request.getSecurityAnswer().trim())
                .build());
        return UserDTO.from(userRepository.save(user));
    }

    @Transactional
    public UserDTO changeRole(String username, Roles newRole) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No user was found with that username. Check the username and try again."));
        user.setRole(newRole);
        return UserDTO.from(userRepository.save(user));
    }

    @Transactional
    public UserDTO deactivate(@NonNull Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No user was found with that ID. Check the ID and try again."));
        user.setUserState(Status.Deactivated);
        return UserDTO.from(userRepository.save(user));
    }
}
