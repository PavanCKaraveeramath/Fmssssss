package com.faultmanagement.utility;

/**
 * IPv4 validation. Rejects null/malformed text, octets outside 0-255, 0.0.0.0, 255.255.255.255 and
 * subnet / broadcast masks such as 255.255.255.0 (any value made of leading 1-bits followed by 0-bits).
 */
public final class IpAddressUtil {

    public static final String INVALID_MESSAGE =
            "Enter a valid device IPv4 address, such as 192.168.1.10. Network masks and 0.0.0.0 or 255.255.255.255 are not accepted.";

    private IpAddressUtil() {
    }

    public static boolean isValid(String ip) {
        if (ip == null) {
            return false;
        }
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) {
            return false;
        }
        long value = 0;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) {
                return false;
            }
            for (int i = 0; i < part.length(); i++) {
                if (part.charAt(i) < '0' || part.charAt(i) > '9') {
                    return false;
                }
            }
            int octet = Integer.parseInt(part);
            if (octet > 255) {
                return false;
            }
            value = (value << 8) | octet;
        }
        return !isMask(value);
    }

    /** 0.0.0.0, 255.255.255.255, 255.255.255.0, 255.255.0.0 ... */
    private static boolean isMask(long value) {
        long inverted = ~value & 0xFFFFFFFFL;
        return (inverted & (inverted + 1)) == 0;
    }
}
