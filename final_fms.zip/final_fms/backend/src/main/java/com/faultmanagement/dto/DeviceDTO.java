package com.faultmanagement.dto;

import com.faultmanagement.entity.Device;
import com.faultmanagement.entity.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class DeviceDTO {

    private final Long id;
    private final String serialNumber;
    private final String ipAddress;
    private final String deviceType;
    private final Status deviceState;

    public static DeviceDTO from(Device device) {
        return DeviceDTO.builder()
                .id(device.getId())
                .serialNumber(device.getSerialNumber())
                .ipAddress(device.getIpAddress())
                .deviceType(device.getDeviceType())
                .deviceState(device.getDeviceState())
                .build();
    }
}
