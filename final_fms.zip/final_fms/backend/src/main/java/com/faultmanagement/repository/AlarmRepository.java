package com.faultmanagement.repository;

import com.faultmanagement.entity.Alarm;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.AlarmStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface AlarmRepository extends JpaRepository<Alarm, Long> {

    List<Alarm> findByStatus(AlarmStatus status);

    Page<Alarm> findByStatus(AlarmStatus status, Pageable pageable);

    List<Alarm> findBySeverity(AlarmSeverity severity);

    Page<Alarm> findBySeverity(AlarmSeverity severity, Pageable pageable);

    List<Alarm> findByDeviceIp(String deviceIp);

    Page<Alarm> findByDeviceIp(String deviceIp, Pageable pageable);

    /**
     * Custom search used by the Manager "Fault handling" screen.
     * <ul>
     *   <li>terminated alarms are always excluded (they stay in the DB only for archiving)</li>
     *   <li>{@code pattern} is a lower-cased LIKE pattern ("%" matches everything) applied to IP, serial and trap name</li>
     *   <li>{@code deviceIp} = "" disables the exact-IP filter</li>
     *   <li>{@code severities} is never empty (the service passes every value when no filter is requested), so no
     *       NULL parameters are needed and the query behaves identically on every database</li>
     * </ul>
     */
    @Query("""
            SELECT a FROM Alarm a
            WHERE a.status <> :excluded
              AND a.severity IN :severities
              AND (:deviceIp = '' OR a.deviceIp = :deviceIp)
              AND (LOWER(a.deviceIp) LIKE :pattern
                   OR LOWER(a.serialNumber) LIKE :pattern
                   OR LOWER(a.alarmName) LIKE :pattern)
            """)
    Page<Alarm> searchActive(@Param("excluded") AlarmStatus excluded,
                             @Param("severities") Collection<AlarmSeverity> severities,
                             @Param("deviceIp") String deviceIp,
                             @Param("pattern") String pattern,
                             Pageable pageable);

    @Query("SELECT a.severity, COUNT(a) FROM Alarm a GROUP BY a.severity")
    List<Object[]> countGroupedBySeverity();

    @Query("SELECT a.status, COUNT(a) FROM Alarm a GROUP BY a.status")
    List<Object[]> countGroupedByStatus();
}
