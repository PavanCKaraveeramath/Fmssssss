package com.faultmanagement.api;

import com.faultmanagement.dto.ReportResponse;
import com.faultmanagement.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/manager/reports", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/by-severity")
    public ResponseEntity<ReportResponse> bySeverity() {
        return ResponseEntity.ok(reportService.bySeverity());
    }

    @GetMapping("/by-status")
    public ResponseEntity<ReportResponse> byStatus() {
        return ResponseEntity.ok(reportService.byStatus());
    }
}
