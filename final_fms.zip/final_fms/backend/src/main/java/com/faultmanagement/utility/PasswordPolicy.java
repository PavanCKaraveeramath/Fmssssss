package com.faultmanagement.utility;

import java.util.regex.Pattern;

/**
 * Password rules from the specification (US03 / US09 / US20):
 * <pre>
 *   0-3 characters -> not accepted
 *   4-6 characters -> Weak
 *   7-8 characters -> Medium      (spec says "6-8"; 6 is already taken by Weak, so Medium starts at 7)
 *   > 8 characters -> Strong
 * </pre>
 * and the password must contain an upper-case letter, a lower-case letter, a digit and one of
 * the special characters {@code @ # $ % & * ! ^}. No other characters are allowed.
 */
public final class PasswordPolicy {

    public static final String REQUIREMENT_MESSAGE =
            "Choose a password with at least 4 characters, including an uppercase letter, a lowercase letter, "
                    + "a number, and one allowed symbol (@ # $ % & * ! ^). Do not use other symbols or spaces.";
    public static final String ALLOWED_SPECIALS = "@#$%&*!^";

    private static final Pattern UPPER = Pattern.compile("[A-Z]");
    private static final Pattern LOWER = Pattern.compile("[a-z]");
    private static final Pattern DIGIT = Pattern.compile("[0-9]");
    private static final Pattern SPECIAL = Pattern.compile("[@#$%&*!^]");
    private static final Pattern ONLY_ALLOWED = Pattern.compile("^[A-Za-z0-9@#$%&*!^]+$");

    public enum Strength {
        NOT_ACCEPTED("Not Accepted"), WEAK("Weak"), MEDIUM("Medium"), STRONG("Strong");

        private final String label;

        Strength(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    private PasswordPolicy() {
    }

    public static Strength evaluate(String password) {
        if (password == null || password.length() <= 3) {
            return Strength.NOT_ACCEPTED;
        }
        boolean complex = ONLY_ALLOWED.matcher(password).matches()
                && UPPER.matcher(password).find()
                && LOWER.matcher(password).find()
                && DIGIT.matcher(password).find()
                && SPECIAL.matcher(password).find();
        if (!complex) {
            return Strength.NOT_ACCEPTED;
        }
        int length = password.length();
        if (length <= 6) {
            return Strength.WEAK;
        }
        return length <= 8 ? Strength.MEDIUM : Strength.STRONG;
    }

    public static boolean isAcceptable(String password) {
        return evaluate(password) != Strength.NOT_ACCEPTED;
    }
}
