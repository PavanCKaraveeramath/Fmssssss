package com.faultmanagement.service;

import com.faultmanagement.dto.AlarmDTO;
import com.faultmanagement.dto.PageResponse;
import org.springframework.data.domain.Pageable;
import org.springframework.lang.NonNull;

import java.util.List;

public interface AlarmService {

    String ONLY_ACK_CAN_BE_CLEARED =
            "This fault is still open. Acknowledge it before clearing it.";
    String ONLY_ACK_OR_CLEARED_CAN_BE_TERMINATED =
            "This fault is still open. Acknowledge or clear it before terminating it.";

    PageResponse<AlarmDTO> listActive(String search, String deviceIp, String severity, Pageable pageable);

    List<AlarmDTO> acknowledge(List<Long> ids);

    List<AlarmDTO> clear(List<Long> ids);

    List<AlarmDTO> terminate(List<Long> ids);

    AlarmDTO updateNotes(@NonNull Long id, String notes);
}
