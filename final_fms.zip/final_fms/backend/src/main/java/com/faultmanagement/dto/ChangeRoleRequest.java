package com.faultmanagement.dto;

import com.faultmanagement.entity.Roles;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ChangeRoleRequest {

    @NotNull(message = "{validation.role.required}")
    private Roles role;
}
