package com.faultmanagement.dto;

import com.faultmanagement.utility.ValidIpAddress;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DeviceUpdateRequest {

    @NotBlank(message = "{validation.device.ip.required}")
    @ValidIpAddress
    private String ipAddress;
}
