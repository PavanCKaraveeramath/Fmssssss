package com.faultmanagement.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class AlarmActionRequest {

    private Long id;
    private List<Long> ids;

    public List<Long> resolveIds() {
        LinkedHashSet<Long> all = new LinkedHashSet<>();
        if (id != null) {
            all.add(id);
        }
        if (ids != null) {
            ids.stream().filter(java.util.Objects::nonNull).forEach(all::add);
        }
        return new ArrayList<>(all);
    }
}
