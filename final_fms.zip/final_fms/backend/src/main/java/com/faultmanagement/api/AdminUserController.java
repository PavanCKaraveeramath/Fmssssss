package com.faultmanagement.api;

import com.faultmanagement.dto.*;
import com.faultmanagement.service.UserAdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping(value = "/api/admin/users", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class AdminUserController {

    private final UserAdminService userAdminService;

    @GetMapping
    public ResponseEntity<PageResponse<UserDTO>> listUsers(@PageableDefault(size = 10) Pageable pageable) {
        Pageable requiredPageable = Objects.requireNonNull(pageable);
        return ResponseEntity.ok(userAdminService.listUsers(requiredPageable));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<UserDTO>> addUser(@Valid @RequestBody CreateUserRequest request) {
        UserDTO created = userAdminService.addUser(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.of("The user was added successfully and can now sign in.", created));
    }

    @PutMapping("/{username}/role")
    public ResponseEntity<ApiResponse<UserDTO>> changeRole(
            @PathVariable String username, @Valid @RequestBody ChangeRoleRequest request) {
        ApiResponse<UserDTO> response = ApiResponse.of("The user's role was changed successfully.",
                userAdminService.changeRole(username, request.getRole()));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<ApiResponse<UserDTO>> deactivate(@PathVariable Long userId) {
        Long requiredUserId = Objects.requireNonNull(userId);
        UserDTO deactivated = userAdminService.deactivate(requiredUserId);
        return ResponseEntity.ok(
                ApiResponse.of("The user was deactivated successfully and can no longer sign in.", deactivated));
     }
}
