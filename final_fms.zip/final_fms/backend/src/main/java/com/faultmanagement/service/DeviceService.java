package com.faultmanagement.service;

import com.faultmanagement.dto.DeviceDTO;
import com.faultmanagement.dto.DeviceRequest;
import com.faultmanagement.dto.PageResponse;
import org.springframework.data.domain.Pageable;

public interface DeviceService {

    PageResponse<DeviceDTO> listActive(Pageable pageable);

    DeviceDTO addDevice(DeviceRequest request);

    DeviceDTO updateIp(String serialNumber, String newIp);

    void deactivate(String serialNumber);
}
