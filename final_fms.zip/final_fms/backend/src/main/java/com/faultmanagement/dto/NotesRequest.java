package com.faultmanagement.dto;

import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class NotesRequest {

    @Size(max = 500, message = "{validation.notes.max-size}")
    private String notes;
}
