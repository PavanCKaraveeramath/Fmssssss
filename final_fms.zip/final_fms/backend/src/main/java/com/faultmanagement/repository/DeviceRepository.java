package com.faultmanagement.repository;

import com.faultmanagement.entity.Device;
import com.faultmanagement.entity.Status;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long> {

    Optional<Device> findBySerialNumber(String serialNumber);

    Optional<Device> findByIpAddress(String ipAddress);

    List<Device> findByDeviceState(Status deviceState);

    Page<Device> findByDeviceState(Status deviceState, Pageable pageable);

    boolean existsBySerialNumber(String serialNumber);

    boolean existsByIpAddress(String ipAddress);

    List<Device> findBySerialNumberIn(Collection<String> serialNumbers);
}
