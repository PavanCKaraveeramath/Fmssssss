package com.faultmanagement.service;

import com.faultmanagement.dto.DeviceDTO;
import com.faultmanagement.dto.DeviceRequest;
import com.faultmanagement.dto.PageResponse;
import com.faultmanagement.entity.Device;
import com.faultmanagement.entity.Status;
import com.faultmanagement.exception.DuplicateResourceException;
import com.faultmanagement.exception.FaultManagementException;
import com.faultmanagement.repository.DeviceRepository;
import com.faultmanagement.utility.IpAddressUtil;
import com.faultmanagement.utility.PageRequests;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Locale;
import java.util.Objects;

@Service
public class DeviceServiceImpl implements DeviceService {

    @Autowired
    private DeviceRepository deviceRepository;

    @Transactional(readOnly = true)
    public PageResponse<DeviceDTO> listActive(Pageable pageable) {
        return PageResponse.from(
                deviceRepository.findByDeviceState(Status.Activated,
                        PageRequests.of(pageable, Sort.by(Sort.Direction.ASC, "id"))),
                DeviceDTO::from);
    }

    @Transactional
    public DeviceDTO addDevice(DeviceRequest request) {
        String serial = request.getSerialNumber().trim();
        String ip = request.getIpAddress().trim();
        requireValidIp(ip);
        if (deviceRepository.existsBySerialNumber(serial)) {
            throw new DuplicateResourceException(
                    "A device with that serial number already exists. Check the serial number and try again.");
        }
        if (deviceRepository.existsByIpAddress(ip)) {
            throw new DuplicateResourceException(
                    "A device with that IP address already exists. Check the IP address and try again.");
        }
        String type = request.getDeviceType().trim().toLowerCase(Locale.ROOT);
        Device device = Objects.requireNonNull(Device.builder()
                .serialNumber(serial)
                .ipAddress(ip)
                .deviceType(Character.toUpperCase(type.charAt(0)) + type.substring(1))
                .deviceState(Status.Activated)
                .build());
        return DeviceDTO.from(deviceRepository.save(device));
    }

    @Transactional
    public DeviceDTO updateIp(String serialNumber, String newIp) {
        Device device = deviceRepository.findBySerialNumber(serialNumber.trim())
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No device was found with that serial number. Check the serial number and try again."));
        String ip = newIp == null ? null : newIp.trim();
        requireValidIp(ip);
        deviceRepository.findByIpAddress(ip).ifPresent(other -> {
            if (!other.getId().equals(device.getId())) {
                throw new DuplicateResourceException(
                        "Another device is already using that IP address. Enter a different IP address.");
            }
        });
        device.setIpAddress(ip);
        return DeviceDTO.from(deviceRepository.save(device));
    }

    @Transactional
    public void deactivate(String serialNumber) {
        Device device = deviceRepository.findBySerialNumber(serialNumber.trim())
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No device was found with that serial number. Check the serial number and try again."));
        device.setDeviceState(Status.Deactivated);
        deviceRepository.save(device);
    }

    private void requireValidIp(String ip) {
        if (!IpAddressUtil.isValid(ip)) {
            throw FaultManagementException.badRequest(IpAddressUtil.INVALID_MESSAGE);
        }
    }
}
