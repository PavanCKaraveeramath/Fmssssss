package com.faultmanagement.api;

import com.faultmanagement.dto.*;
import com.faultmanagement.service.AlarmService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api/manager/faults", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class FaultController {

    private final AlarmService alarmService;

    @GetMapping
    public ResponseEntity<PageResponse<AlarmDTO>> listFaults(@RequestParam(required = false) String search,
                                                              @RequestParam(required = false) String deviceIp,
                                                              @RequestParam(required = false) String severity,
                                                              @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(alarmService.listActive(search, deviceIp, severity, pageable));
    }

    @PostMapping("/acknowledge")
    public ResponseEntity<ApiResponse<Map<String, Object>>> acknowledge(@RequestBody AlarmActionRequest request) {
        return ResponseEntity.ok(result("acknowledged", alarmService.acknowledge(request.resolveIds())));
    }

    @PostMapping("/clear")
    public ResponseEntity<ApiResponse<Map<String, Object>>> clear(@RequestBody AlarmActionRequest request) {
        return ResponseEntity.ok(result("cleared", alarmService.clear(request.resolveIds())));
    }

    @PostMapping("/terminate")
    public ResponseEntity<ApiResponse<Map<String, Object>>> terminate(@RequestBody AlarmActionRequest request) {
        return ResponseEntity.ok(result("terminated", alarmService.terminate(request.resolveIds())));
    }

    @PutMapping("/{id}/notes")
    public ResponseEntity<ApiResponse<AlarmDTO>> updateNotes(@PathVariable @NonNull Long id,
                                                              @Valid @RequestBody NotesRequest request) {
        ApiResponse<AlarmDTO> response = ApiResponse.of("The fault notes were updated successfully.",
                alarmService.updateNotes(id, request.getNotes()));
        return ResponseEntity.ok(response);
    }

    private ApiResponse<Map<String, Object>> result(String verb, List<AlarmDTO> alarms) {
        String message = alarms.size() == 1
                ? "The fault was " + verb + " successfully."
                : alarms.size() + " faults were " + verb + " successfully.";
        return ApiResponse.of(message, Map.of("updated", alarms.size(), "alarms", alarms));
    }
}
