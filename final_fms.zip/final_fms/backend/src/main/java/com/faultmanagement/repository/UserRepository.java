package com.faultmanagement.repository;

import com.faultmanagement.entity.Roles;
import com.faultmanagement.entity.User;
import com.faultmanagement.entity.Status;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    boolean existsByUsername(String username);

    List<User> findByUserState(Status userState);

    Page<User> findByUserState(Status userState, Pageable pageable);

    long countByRoleAndUserState(Roles role, Status userState);
}
