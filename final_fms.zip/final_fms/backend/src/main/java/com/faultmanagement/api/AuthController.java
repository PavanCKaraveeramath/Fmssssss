package com.faultmanagement.api;

import com.faultmanagement.dto.*;
import com.faultmanagement.service.UserLoginService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping(value = "/api/auth", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class AuthController {

    private final UserLoginService userLoginService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(userLoginService.login(request));
    }

    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<Map<String, String>>> changePassword(
            @Valid @RequestBody ChangePasswordRequest request) {
        return ResponseEntity.ok(userLoginService.changePassword(request));
    }

    @PostMapping("/forgot-password/get-question")
    public ResponseEntity<ApiResponse<Map<String, String>>> getQuestion(
            @Valid @RequestBody ForgotQuestionRequest request) {
        String username = request.getUsername().trim();
        ApiResponse<Map<String, String>> response = ApiResponse.of(
                "Security question retrieved. Answer it to reset your password.",
                Map.of("username", username, "securityQuestion", userLoginService.getSecurityQuestion(username)));
        return ResponseEntity.ok(response);
    }

    @PostMapping("/forgot-password/reset")
    public ResponseEntity<ApiResponse<Void>> reset(@Valid @RequestBody ResetPasswordRequest request) {
        userLoginService.resetPassword(request);
        return ResponseEntity.ok(
                ApiResponse.of("Your password was reset successfully. You can now sign in with the new password."));
    }
}
