package com.faultmanagement.entity;

import java.util.Locale;

public enum AlarmSeverity {
    CLEAR, WARNING, MAJOR, SEVERE, CRITICAL;

    public static AlarmSeverity fromText(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        try {
            return AlarmSeverity.valueOf(text.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
