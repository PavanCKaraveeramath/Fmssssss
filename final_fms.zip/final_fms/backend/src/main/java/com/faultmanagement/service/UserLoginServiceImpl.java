 package com.faultmanagement.service;

import com.faultmanagement.dto.*;
import com.faultmanagement.entity.Roles;
import com.faultmanagement.entity.Status;
import com.faultmanagement.entity.User;
import com.faultmanagement.exception.FaultManagementException;
import com.faultmanagement.repository.UserRepository;
import com.faultmanagement.security.JwtService;
import com.faultmanagement.utility.PasswordPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
public class UserLoginServiceImpl implements UserLoginService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Transactional(readOnly = true)
    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername().trim())
                .orElseThrow(() -> FaultManagementException.unauthorized(
                        "The username or password is incorrect. Check your details and try again."));
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw FaultManagementException.unauthorized(
                    "The username or password is incorrect. Check your details and try again.");
        }
        if (user.getUserState() == Status.Deactivated) {
            throw FaultManagementException.forbidden(
                    "This account is deactivated. Contact an administrator for help.");
        }
        Roles role = user.getRole();
        return LoginResponse.builder()
                .message("Welcome, " + user.getUsername() + "! You are signed in as " + role.display() + ".")
                .token(jwtService.generateToken(user.getUsername(), role))
                .username(user.getUsername())
                .role(role)
                .build();
    }

    @Transactional
    public ApiResponse<Map<String, String>> changePassword(ChangePasswordRequest request) {
        User user = userRepository.findByUsername(request.getUsername().trim())
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No account was found for that username. Check the username and try again."));
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw FaultManagementException.badRequest(
                    "The current password is incorrect. Check it and try again.");
        }
        PasswordPolicy.Strength strength = PasswordPolicy.evaluate(request.getNewPassword());
        if (strength == PasswordPolicy.Strength.NOT_ACCEPTED) {
            throw FaultManagementException.badRequest(PasswordPolicy.REQUIREMENT_MESSAGE);
        }
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        return ApiResponse.of("Your password was changed successfully. Please sign in again.",
                Map.of("strength", strength.label()));
    }

    @Transactional(readOnly = true)
    public String getSecurityQuestion(String username) {
        return userRepository.findByUsername(username.trim())
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No account was found for that username. Check the username and try again."))
                .getSecurityQuestion();
    }

    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        User user = userRepository.findByUsername(request.getUsername().trim())
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No account was found for that username. Check the username and try again."));
        if (user.getSecurityAnswer() == null
                || !user.getSecurityAnswer().trim().equalsIgnoreCase(request.getSecurityAnswer().trim())) {
            throw FaultManagementException.badRequest(
                    "The security answer is incorrect. Check your answer and try again.");
        }
        if (!PasswordPolicy.isAcceptable(request.getNewPassword())) {
            throw FaultManagementException.badRequest(PasswordPolicy.REQUIREMENT_MESSAGE);
        }
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
    }
}
