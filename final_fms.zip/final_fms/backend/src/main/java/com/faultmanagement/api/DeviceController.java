package com.faultmanagement.api;

import com.faultmanagement.dto.*;
import com.faultmanagement.service.DeviceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/api/operator/devices", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class DeviceController {

    private final DeviceService deviceService;

    @GetMapping
    public ResponseEntity<PageResponse<DeviceDTO>> listDevices(@PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(deviceService.listActive(pageable));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<DeviceDTO>> addDevice(@Valid @RequestBody DeviceRequest request) {
        DeviceDTO created = deviceService.addDevice(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.of("The device was added successfully and is now active.", created));
    }

    @PutMapping("/{serialNumber}")
    public ResponseEntity<ApiResponse<DeviceDTO>> updateDevice(
            @PathVariable String serialNumber, @Valid @RequestBody DeviceUpdateRequest request) {
        ApiResponse<DeviceDTO> response = ApiResponse.of("The device IP address was updated successfully.",
                deviceService.updateIp(serialNumber, request.getIpAddress()));
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{serialNumber}")
    public ResponseEntity<ApiResponse<Void>> deactivateDevice(@PathVariable String serialNumber) {
        deviceService.deactivate(serialNumber);
        return ResponseEntity.ok(
                ApiResponse.of("The device was deactivated successfully and removed from the active device list."));
    }
}
