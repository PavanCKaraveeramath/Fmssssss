package com.faultmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "devices")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Device {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "serial_number", nullable = false, unique = true, length = 100)
    private String serialNumber;

    @Column(name = "ip_address", nullable = false, unique = true, length = 45)
    private String ipAddress;

    @Column(name = "device_type", nullable = false, length = 100)
    private String deviceType;

    @Enumerated(EnumType.STRING)
    @Column(name = "device_state", nullable = false, length = 20)
    @Builder.Default
    private Status deviceState = Status.Activated;
}
