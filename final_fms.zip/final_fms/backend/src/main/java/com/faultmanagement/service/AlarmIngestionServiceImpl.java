package com.faultmanagement.service;

import com.faultmanagement.dto.xml.AlarmInfoXml;
import com.faultmanagement.dto.xml.AlarmListXml;
import com.faultmanagement.entity.Alarm;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.AlarmStatus;
import com.faultmanagement.repository.AlarmRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@Service
@Slf4j
public class AlarmIngestionServiceImpl implements AlarmIngestionService {

    @Autowired
    private AlarmRepository alarmRepository;

    private final XmlMapper xmlMapper = createXmlMapper();

    @Value("${fm.simulator.input-dir}")
    private String inputDir;

    @Value("${fm.simulator.processed-dir}")
    private String processedDir;

    private static XmlMapper createXmlMapper() {
        XmlMapper mapper = new XmlMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper;
    }

    @Scheduled(fixedDelayString = "${fm.ingestion.poll-interval-ms:15000}", initialDelay = 5000)
    public void scheduledIngestion() {
        try {
            ingestPendingFiles();
        } catch (Exception ex) {
            log.error("Alarm ingestion failed", ex);
        }
    }

    @Override
    public synchronized int ingestPendingFiles() throws IOException {
        Path inputDirectory = Path.of(inputDir);
        Path processedDirectory = Path.of(processedDir);
        Files.createDirectories(inputDirectory);
        Files.createDirectories(processedDirectory);
        List<Path> files;
        try (Stream<Path> stream = Files.list(inputDirectory)) {
            files = stream.filter(p -> p.getFileName().toString().endsWith(".xml")).sorted().toList();
        }
        int stored = 0;
        for (Path file : files) {
            try {
                stored += ingestXml(Files.readString(file, StandardCharsets.UTF_8)).size();
            } catch (Exception ex) {
                log.error("Could not ingest {}", file.getFileName(), ex);
                continue;
            }
            Files.move(file, processedDirectory.resolve(file.getFileName()), StandardCopyOption.REPLACE_EXISTING);
        }
        if (stored > 0) {
            log.info("Ingestion stored {} alarm(s)", stored);
        }
        return stored;
    }

    @Override
    public List<Alarm> ingestXml(String xml) throws JsonProcessingException {
        AlarmListXml list = xmlMapper.readValue(xml, AlarmListXml.class);
        List<Alarm> alarms = new ArrayList<>();
        for (AlarmInfoXml info : list.getAlarms()) {
            alarms.add(toAlarm(info));
        }
        return alarmRepository.saveAll(alarms);
    }

    private Alarm toAlarm(AlarmInfoXml info) {
        AlarmSeverity severity = AlarmSeverity.fromText(info.getSeverity());
        long now = System.currentTimeMillis();
        String note = info.getAdditionalText();
        return Alarm.builder()
                .alarmName(info.getAlarmName())
                .deviceIp(info.getNodeId())
                .serialNumber(info.getNodeName())
                .severity(severity == null ? AlarmSeverity.WARNING : severity)
                .status(AlarmStatus.OPEN)
                .probableCause(info.getProbableCause())
                .occurrenceCount(info.getNumberOfOccurences() == null ? 1 : info.getNumberOfOccurences())
                .firstTimeDetected(info.getFirstTimeDetected() == null ? now : info.getFirstTimeDetected())
                .lastTimeDetected(info.getLastTimeDetected() == null ? now : info.getLastTimeDetected())
                .notes(note == null || note.isBlank() || "N/A".equalsIgnoreCase(note.trim()) ? null : note.trim())
                .build();
    }
}
