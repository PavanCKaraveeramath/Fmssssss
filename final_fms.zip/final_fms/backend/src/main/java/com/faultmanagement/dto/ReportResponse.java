package com.faultmanagement.dto;

import lombok.Getter;

import java.util.Map;

@Getter
public class ReportResponse {

    private final String message;
    private final String report;
    private final long total;
    private final Map<String, Long> counts;

    public ReportResponse(String report, long total, Map<String, Long> counts) {
        this.message = "Report generated successfully. " + total
                + (total == 1 ? " fault included." : " faults included.");
        this.report = report;
        this.total = total;
        this.counts = counts;
    }
}
