package com.faultmanagement.dto;

import com.faultmanagement.entity.Roles;
import com.faultmanagement.entity.User;
import com.faultmanagement.entity.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class UserDTO {

    private final Long id;
    private final String username;
    private final Roles role;
    private final Status userState;

    public static UserDTO from(User user) {
        return UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .role(user.getRole())
                .userState(user.getUserState())
                .build();
    }
}
