package com.faultmanagement.entity;

public enum Status {
    Activated, Deactivated
}
