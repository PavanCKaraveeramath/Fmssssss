package com.faultmanagement.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class FaultManagementException extends RuntimeException {

    private final HttpStatus status;

    public FaultManagementException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public static FaultManagementException badRequest(String message) {
        return new FaultManagementException(HttpStatus.BAD_REQUEST, message);
    }

    public static FaultManagementException unauthorized(String message) {
        return new FaultManagementException(HttpStatus.UNAUTHORIZED, message);
    }

    public static FaultManagementException forbidden(String message) {
        return new FaultManagementException(HttpStatus.FORBIDDEN, message);
    }

    public static FaultManagementException notFound(String message) {
        return new FaultManagementException(HttpStatus.NOT_FOUND, message);
    }
}
