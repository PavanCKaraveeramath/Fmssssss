package com.faultmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "alarms")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Alarm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "alarm_name", nullable = false)
    private String alarmName;

    @Column(name = "device_ip", nullable = false, length = 45)
    private String deviceIp;

    @Column(name = "serial_number", nullable = false, length = 100)
    private String serialNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AlarmSeverity severity;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private AlarmStatus status = AlarmStatus.OPEN;

    @Column(name = "probable_cause")
    private Integer probableCause;

    @Column(name = "occurrence_count")
    private Integer occurrenceCount;

    /** epoch millis */
    @Column(name = "first_time_detected")
    private Long firstTimeDetected;

    /** epoch millis */
    @Column(name = "last_time_detected")
    private Long lastTimeDetected;

    @Column(length = 500)
    private String notes;
}
