package com.faultmanagement.dto;

import com.faultmanagement.entity.Roles;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CreateUserRequest {

    @NotBlank(message = "{validation.username.required}")
    private String username;

    @NotBlank(message = "{validation.password.required}")
    private String password;

    @NotNull(message = "{validation.role.required}")
    private Roles role;

    @NotBlank(message = "{validation.security-question.required}")
    private String securityQuestion;

    @NotBlank(message = "{validation.security-answer.required}")
    private String securityAnswer;
}
