package com.faultmanagement.service;

import com.faultmanagement.dto.ApiResponse;
import com.faultmanagement.dto.ChangePasswordRequest;
import com.faultmanagement.dto.LoginRequest;
import com.faultmanagement.dto.LoginResponse;
import com.faultmanagement.dto.ResetPasswordRequest;

import java.util.Map;

public interface UserLoginService {

    LoginResponse login(LoginRequest request);

    ApiResponse<Map<String, String>> changePassword(ChangePasswordRequest request);

    String getSecurityQuestion(String username);

    void resetPassword(ResetPasswordRequest request);
}
