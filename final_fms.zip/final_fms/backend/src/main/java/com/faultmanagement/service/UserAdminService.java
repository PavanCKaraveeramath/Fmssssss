package com.faultmanagement.service;

import com.faultmanagement.dto.CreateUserRequest;
import com.faultmanagement.dto.PageResponse;
import com.faultmanagement.dto.UserDTO;
import com.faultmanagement.entity.Roles;
import org.springframework.lang.NonNull;
import org.springframework.data.domain.Pageable;

public interface UserAdminService {

    PageResponse<UserDTO> listUsers(@NonNull Pageable pageable);

    UserDTO addUser(CreateUserRequest request);

    UserDTO changeRole(String username, Roles newRole);

    UserDTO deactivate(@NonNull Long userId);
}
