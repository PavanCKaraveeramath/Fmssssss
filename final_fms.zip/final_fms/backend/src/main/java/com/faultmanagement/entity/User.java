package com.faultmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = {"password", "securityAnswer"})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String username;

    /** BCrypt hash - never the clear text. */
    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Roles role;

    @Enumerated(EnumType.STRING)
    @Column(name = "user_state", nullable = false, length = 20)
    @Builder.Default
    private Status userState = Status.Activated;

    @Column(name = "security_question")
    private String securityQuestion;

    /** BCrypt hash of the trimmed, lower-cased answer. */
    @Column(name = "security_answer")
    private String securityAnswer;
}
