package com.faultmanagement.service;

import com.faultmanagement.entity.Alarm;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.util.List;

public interface AlarmIngestionService {

    int ingestPendingFiles() throws IOException;

    List<Alarm> ingestXml(String xml) throws JsonProcessingException;
}
