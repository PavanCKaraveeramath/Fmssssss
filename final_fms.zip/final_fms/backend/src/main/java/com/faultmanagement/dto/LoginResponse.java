package com.faultmanagement.dto;

import com.faultmanagement.entity.Roles;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class LoginResponse {

    private final String message;
    private final String token;
    private final String username;
    private final Roles role;
}
