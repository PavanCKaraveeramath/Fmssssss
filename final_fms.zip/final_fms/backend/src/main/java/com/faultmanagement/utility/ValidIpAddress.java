package com.faultmanagement.utility;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

/** Bean Validation constraint for IPv4 device addresses. Null is left to {@code @NotBlank}. */
@Documented
@Constraint(validatedBy = IpAddressConstraintValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidIpAddress {

    String message() default "{validation.device.ip.invalid}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
