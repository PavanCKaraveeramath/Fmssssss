package com.faultmanagement.utility;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class IpAddressConstraintValidator implements ConstraintValidator<ValidIpAddress, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        // null/blank is reported by @NotBlank so the client gets a single, clear message
        if (value == null || value.isBlank()) {
            return true;
        }
        return IpAddressUtil.isValid(value);
    }
}
