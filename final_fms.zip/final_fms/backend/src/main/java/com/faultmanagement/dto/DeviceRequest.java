package com.faultmanagement.dto;

import com.faultmanagement.utility.ValidIpAddress;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DeviceRequest {

    @NotBlank(message = "{validation.device.serial.required}")
    @Pattern(regexp = "^[A-Za-z0-9_-]{3,50}$",
            message = "{validation.device.serial.format}")
    private String serialNumber;

    @NotBlank(message = "{validation.device.ip.required}")
    @ValidIpAddress
    private String ipAddress;

    @NotBlank(message = "{validation.device.type.required}")
    @Pattern(regexp = "(?i)^(Router|Switch|Hub)$", message = "{validation.device.type.format}")
    private String deviceType;
}
