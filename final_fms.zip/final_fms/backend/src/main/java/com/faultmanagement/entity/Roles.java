package com.faultmanagement.entity;

public enum Roles {
    ADMIN, OPERATOR, MANAGER;

    public String display() {
        String lower = name().toLowerCase();
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }
}
