package com.faultmanagement.entity;

public enum AlarmStatus {
    OPEN, ACKNOWLEDGED, CLEARED, TERMINATED;

    public String lower() {
        return name().toLowerCase();
    }
}
