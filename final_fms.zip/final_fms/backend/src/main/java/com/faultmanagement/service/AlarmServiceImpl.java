package com.faultmanagement.service;

import com.faultmanagement.dto.AlarmDTO;
import com.faultmanagement.dto.PageResponse;
import com.faultmanagement.entity.Alarm;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.AlarmStatus;
import com.faultmanagement.exception.FaultManagementException;
import com.faultmanagement.repository.AlarmRepository;
import com.faultmanagement.repository.DeviceRepository;
import com.faultmanagement.utility.PageRequests;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AlarmServiceImpl implements AlarmService {

    @Autowired
    private AlarmRepository alarmRepository;

    @Autowired
    private DeviceRepository deviceRepository;


    @Transactional(readOnly = true)
    public PageResponse<AlarmDTO> listActive(String search, String deviceIp, String severity, Pageable pageable) {
        List<AlarmSeverity> severities = severity == null || severity.isBlank()
                ? Arrays.asList(AlarmSeverity.values())
                : List.of(parseSeverity(severity));
        String keyword = search == null ? "" : search.trim().toLowerCase(Locale.ROOT).replace("%", "");
        Pageable sorted = PageRequests.of(pageable,
                Sort.by(Sort.Direction.DESC, "lastTimeDetected").and(Sort.by(Sort.Direction.DESC, "id")));

        Page<Alarm> page = alarmRepository.searchActive(AlarmStatus.TERMINATED, severities,
                deviceIp == null ? "" : deviceIp.trim(), "%" + keyword + "%", sorted);

        Map<String, String> types = deviceTypes(page.getContent());
        return PageResponse.from(page, a -> AlarmDTO.from(a, types.get(a.getSerialNumber())));
    }


    @Transactional
    public List<AlarmDTO> acknowledge(List<Long> ids) {
        List<Alarm> alarms = load(ids);
        for (Alarm alarm : alarms) {
            if (alarm.getStatus() != AlarmStatus.OPEN) {
                throw FaultManagementException.badRequest("This fault is already " + alarm.getStatus().lower()
                        + ". Only open faults can be acknowledged.");
            }
        }
        alarms.forEach(a -> a.setStatus(AlarmStatus.ACKNOWLEDGED));
        return toDtos(alarmRepository.saveAll(alarms));
    }

    @Transactional
    public List<AlarmDTO> clear(List<Long> ids) {
        List<Alarm> alarms = load(ids);
        for (Alarm alarm : alarms) {
            switch (alarm.getStatus()) {
                case OPEN -> throw FaultManagementException.badRequest(ONLY_ACK_CAN_BE_CLEARED);
                case CLEARED -> throw FaultManagementException.badRequest("This fault is already cleared.");
                case TERMINATED -> throw FaultManagementException.badRequest("This fault is already terminated.");
                default -> { /* ACKNOWLEDGED - ok */ }
            }
        }
        alarms.forEach(a -> {
            a.setStatus(AlarmStatus.CLEARED);
            a.setSeverity(AlarmSeverity.CLEAR);
        });
        return toDtos(alarmRepository.saveAll(alarms));
    }

    @Transactional
    public List<AlarmDTO> terminate(List<Long> ids) {
        List<Alarm> alarms = load(ids);
        for (Alarm alarm : alarms) {
            if (alarm.getStatus() == AlarmStatus.TERMINATED) {
                throw FaultManagementException.badRequest("This fault is already terminated.");
            }
            if (alarm.getStatus() == AlarmStatus.OPEN) {
                throw FaultManagementException.badRequest(ONLY_ACK_OR_CLEARED_CAN_BE_TERMINATED);
            }
        }
        alarms.forEach(a -> a.setStatus(AlarmStatus.TERMINATED));
        return toDtos(alarmRepository.saveAll(alarms));
    }

    @Transactional
    public AlarmDTO updateNotes(@NonNull Long id, String notes) {
        Alarm alarm = alarmRepository.findById(id)
                .orElseThrow(() -> FaultManagementException.notFound(
                        "No fault was found with ID " + id + ". Check the ID and try again."));
        if (alarm.getStatus() == AlarmStatus.TERMINATED) {
            throw FaultManagementException.badRequest(
                    "Notes cannot be changed because this fault has been terminated.");
        }
        alarm.setNotes(notes == null || notes.isBlank() ? null : notes.trim());
        return toDtos(List.of(alarmRepository.save(alarm))).get(0);
    }


    private List<Alarm> load(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            throw FaultManagementException.badRequest("Select at least one fault before continuing.");
        }
        List<Long> unique = new ArrayList<>(new LinkedHashSet<>(ids));
        Map<Long, Alarm> found = alarmRepository.findAllById(unique).stream()
                .collect(Collectors.toMap(
                        alarm -> Objects.requireNonNull(alarm.getId(), "Loaded alarm must have an ID"),
                        alarm -> alarm));
        List<Alarm> ordered = new ArrayList<>();
        for (Long id : unique) {
            Alarm alarm = found.get(id);
            if (alarm == null) {
                throw FaultManagementException.notFound(
                        "No fault was found with ID " + id + ". Check the ID and try again.");
            }
            ordered.add(alarm);
        }
        return ordered;
    }

    private AlarmSeverity parseSeverity(String text) {
        AlarmSeverity severity = AlarmSeverity.fromText(text);
        if (severity == null) {
            throw FaultManagementException.badRequest(
                    "Invalid severity '" + text + "'. Allowed values: " + Arrays.toString(AlarmSeverity.values()));
        }
        return severity;
    }

    private List<AlarmDTO> toDtos(List<Alarm> alarms) {
        Map<String, String> types = deviceTypes(alarms);
        return alarms.stream()
                .map(alarm -> AlarmDTO.from(alarm,
                        types.get(Objects.requireNonNull(alarm.getSerialNumber(), "Alarm serial number is required"))))
                .toList();
    }

    private Map<String, String> deviceTypes(Collection<Alarm> alarms) {
        Set<String> serials = alarms.stream()
                .map(alarm -> Objects.requireNonNull(alarm.getSerialNumber(), "Alarm serial number is required"))
                .collect(Collectors.toSet());
        if (serials.isEmpty()) {
            return Map.of();
        }
        return deviceRepository.findBySerialNumberIn(serials).stream()
                .collect(Collectors.toMap(
                        device -> Objects.requireNonNull(device.getSerialNumber(), "Device serial number is required"),
                        device -> Objects.requireNonNull(device.getDeviceType(), "Device type is required"),
                        (existingType, duplicateType) -> existingType));
    }
}
