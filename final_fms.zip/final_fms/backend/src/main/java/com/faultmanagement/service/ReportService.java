package com.faultmanagement.service;

import com.faultmanagement.dto.ReportResponse;

public interface ReportService {

    ReportResponse bySeverity();

    ReportResponse byStatus();
}
