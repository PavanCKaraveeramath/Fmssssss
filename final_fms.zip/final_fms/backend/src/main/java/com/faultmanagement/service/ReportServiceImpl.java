package com.faultmanagement.service;

import com.faultmanagement.dto.ReportResponse;
import com.faultmanagement.entity.AlarmSeverity;
import com.faultmanagement.entity.AlarmStatus;
import com.faultmanagement.repository.AlarmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private AlarmRepository alarmRepository;

    @Transactional(readOnly = true)
    public ReportResponse bySeverity() {
        Map<String, Long> counts = new LinkedHashMap<>();
        for (AlarmSeverity s : AlarmSeverity.values()) {
            counts.put(s.name(), 0L);
        }
        fill(counts, alarmRepository.countGroupedBySeverity());
        return new ReportResponse("BY_SEVERITY", sum(counts), counts);
    }

    @Transactional(readOnly = true)
    public ReportResponse byStatus() {
        Map<String, Long> counts = new LinkedHashMap<>();
        for (AlarmStatus s : AlarmStatus.values()) {
            counts.put(s.name(), 0L);
        }
        fill(counts, alarmRepository.countGroupedByStatus());
        return new ReportResponse("BY_STATUS", sum(counts), counts);
    }

    private void fill(Map<String, Long> counts, List<Object[]> rows) {
        for (Object[] row : rows) {
            counts.put(((Enum<?>) row[0]).name(), ((Number) row[1]).longValue());
        }
    }

    private long sum(Map<String, Long> counts) {
        return counts.values().stream().mapToLong(value -> Objects.requireNonNull(value)).sum();
    }
}
