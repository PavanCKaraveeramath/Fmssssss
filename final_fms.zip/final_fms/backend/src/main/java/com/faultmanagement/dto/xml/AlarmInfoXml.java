package com.faultmanagement.dto.xml;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JacksonXmlRootElement(localName = "fm.AlarmInfo")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"severity", "previousSeverity", "originalSeverity", "probableCause", "alarmName", "isAcknowledged",
        "firstTimeDetected", "lastTimeDetected", "numberOfOccurences", "isServiceAffecting", "additionalText", "nodeId", "nodeName",
        "affectedObjectDisplayedName", "applicationDomain", "displayedClass"})
public class AlarmInfoXml {

    @JacksonXmlProperty(localName = "severity")
    private String severity;

    @JacksonXmlProperty(localName = "previousSeverity")
    private String previousSeverity;

    @JacksonXmlProperty(localName = "originalSeverity")
    private String originalSeverity;

    @JacksonXmlProperty(localName = "probableCause")
    private Integer probableCause;

    @JacksonXmlProperty(localName = "alarmName")
    private String alarmName;

    @JacksonXmlProperty(localName = "isAcknowledged")
    private Boolean isAcknowledged;

    @JacksonXmlProperty(localName = "firstTimeDetected")
    private Long firstTimeDetected;

    @JacksonXmlProperty(localName = "lastTimeDetected")
    private Long lastTimeDetected;

    @JacksonXmlProperty(localName = "numberOfOccurences")
    private Integer numberOfOccurences;

    @JacksonXmlProperty(localName = "isServiceAffecting")
    private Boolean isServiceAffecting;

    @JacksonXmlProperty(localName = "additionalText")
    private String additionalText;

    @JacksonXmlProperty(localName = "nodeId")
    private String nodeId;

    @JacksonXmlProperty(localName = "nodeName")
    private String nodeName;

    @JacksonXmlProperty(localName = "affectedObjectDisplayedName")
    private String affectedObjectDisplayedName;

    @JacksonXmlProperty(localName = "applicationDomain")
    private String applicationDomain;

    @JacksonXmlProperty(localName = "displayedClass")
    private String displayedClass;
}
