package com.faultmanagement.exception;

import org.springframework.http.HttpStatus;

public class DuplicateResourceException extends FaultManagementException {

    public DuplicateResourceException(String message) {
        super(HttpStatus.CONFLICT, message);
    }
}
