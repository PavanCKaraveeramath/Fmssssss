# Fault Management System - Frontend

React + Vite + Bootstrap 5 + Axios + Chart.js, connected to the Spring Boot backend (`../backend`).

```bash
npm install
npm run dev        # http://localhost:5173
```
Backend URL: `http://localhost:8080` by default. To change it, copy `.env.example` to `.env` and set `VITE_API_BASE_URL`.
Windows: double-click `setup-and-run.cmd`.
