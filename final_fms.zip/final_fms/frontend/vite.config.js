import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, open: true },
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes("node_modules/react") || id.includes("node_modules/scheduler")) {
            return "react-vendor";
          }
          if (
            id.includes("node_modules/chart.js") ||
            id.includes("node_modules/chartjs") ||
            id.includes("node_modules/react-chartjs-2")
          ) {
            return "charts";
          }
        },
      },
    },
  },
});
