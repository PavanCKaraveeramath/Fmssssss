@echo off
cd /d "%~dp0"
title Fault Management Dashboard
where node >nul 2>nul
if errorlevel 1 (echo Install Node.js LTS from https://nodejs.org/ & pause & exit /b 1)
if not exist node_modules (echo Installing dependencies... & call npm install)
if not exist .env copy .env.example .env >nul
call npm run dev
pause
