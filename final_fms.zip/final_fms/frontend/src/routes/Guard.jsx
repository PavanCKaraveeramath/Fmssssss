import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
export default function Guard({ roles }) {
  let { user } = useAuth(),
    loc = useLocation();
  if (!user) return <Navigate to="/login" replace state={{ from: loc }} />;
  if (roles && !roles.includes(user.role))
    return (
      <Navigate
        to={
          user.role === "ADMIN"
            ? "/admin/users"
            : user.role === "OPERATOR"
              ? "/operator/devices"
              : "/manager/faults"
        }
        replace
      />
    );
  return <Outlet />;
}
