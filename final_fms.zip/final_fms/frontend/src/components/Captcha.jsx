import { useEffect, useRef } from "react";

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function makeCaptcha(length = 6) {
  let out = "";
  const buf = new Uint32Array(length);
  crypto.getRandomValues(buf);
  for (let i = 0; i < length; i++) out += ALPHABET[buf[i] % ALPHABET.length];
  return out;
}

export default function Captcha({ code, onRefresh }) {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const { width, height } = canvas;
    ctx.fillStyle = "#eef2f7";
    ctx.fillRect(0, 0, width, height);
    for (let i = 0; i < 7; i++) {
      ctx.strokeStyle = `hsl(${Math.random() * 360}, 40%, 60%)`;
      ctx.beginPath();
      ctx.moveTo(Math.random() * width, Math.random() * height);
      ctx.lineTo(Math.random() * width, Math.random() * height);
      ctx.stroke();
    }
    ctx.font = "bold 28px monospace";
    ctx.textBaseline = "middle";
    code.split("").forEach((ch, i) => {
      ctx.save();
      ctx.translate(16 + i * 24, height / 2 + (Math.random() * 8 - 4));
      ctx.rotate((Math.random() - 0.5) * 0.7);
      ctx.fillStyle = `hsl(${Math.random() * 360}, 60%, 30%)`;
      ctx.fillText(ch, 0, 0);
      ctx.restore();
    });
  }, [code]);

  return (
    <div className="d-flex align-items-center gap-2">
      <canvas ref={ref} width={170} height={48} className="captcha-canvas" aria-label="Captcha image" />
      <button type="button" className="btn btn-outline-secondary btn-sm" onClick={onRefresh} title="New captcha">
        <i className="bi bi-arrow-clockwise" />
      </button>
    </div>
  );
}
