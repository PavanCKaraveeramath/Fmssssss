import { useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { HOME_BY_ROLE, useAuth } from "../context/AuthContext.jsx";
import ChangePasswordModal from "./ChangePasswordModal.jsx";

const links = {
  ADMIN: [
    ["/admin/users", "User Details"],
    ["/admin/users/new", "Add User"],
    ["/admin/change-role", "Change Role"],
    ["/admin/delete-user", "Delete User"],
    ["/admin/reports", "Report"],
  ],
  OPERATOR: [
    ["/operator/devices", "Device List"],
    ["/operator/devices/new", "Add Device"],
    ["/operator/edit-device", "Edit Device"],
    ["/operator/delete-device", "Delete Device"],
    ["/operator/reports", "Report"],
  ],
  MANAGER: [
    ["/manager/faults", "Fault Handling"],
    ["/manager/reports", "Report"],
  ],
};

const navIcons = {
  "User Details": "bi-people",
  "Add User": "bi-person-plus",
  "Change Role": "bi-person-gear",
  "Delete User": "bi-person-dash",
  "Device List": "bi-hdd-network",
  "Add Device": "bi-plus-square",
  "Edit Device": "bi-pencil-square",
  "Delete Device": "bi-trash3",
  "Fault Handling": "bi-activity",
  Report: "bi-bar-chart-line",
};

export default function Layout() {
  const { user, logout } = useAuth();
  const [showChange, setShowChange] = useState(false);

  return (
    <div className="shell">
      <aside className="sidebar">
        <Link to={HOME_BY_ROLE[user.role]} className="brand sidebar-brand">
          <span className="brand-mark"><i className="bi bi-broadcast-pin" aria-hidden="true" /></span>
          <span>Fault Management<small>OPERATIONS CONSOLE</small></span>
        </Link>
        <small className="muted"><span className="status-dot" /> {user.role} WORKSPACE</small>
        {links[user.role].map(([to, label]) => (
          <NavLink key={to} to={to} end className={({ isActive }) => "side-link " + (isActive ? "active" : "")}>
            <i className={`bi ${navIcons[label]}`} aria-hidden="true" />
            <span>{label}</span>
          </NavLink>
        ))}
        <div className="sidebar-foot"><i className="bi bi-shield-check" aria-hidden="true" /><span>System operational</span></div>
      </aside>
      <main className="main">
        <header className="topbar">
          <Link to={HOME_BY_ROLE[user.role]} className="text-decoration-none" title="Home">
            <b><i className="bi bi-house-door-fill me-2" />Fault Management System</b>
          </Link>
          <span className="topbar-actions">
            <span className="account-chip"><span className="account-avatar">{user.username.slice(0, 1).toUpperCase()}</span><span className="account-copy"><small>{user.role}</small><b>{user.username}</b></span></span>
            <button className="btn btn-outline-secondary btn-sm" onClick={() => setShowChange(true)}>
              Change Password
            </button>
            <button className="btn btn-outline-danger btn-sm" onClick={() => logout()}>
              Logout
            </button>
          </span>
        </header>
        <section className="content">
          <Outlet />
        </section>
        <footer className="footer">Fault Management System</footer>
      </main>
      {showChange && <ChangePasswordModal onClose={() => setShowChange(false)} />}
    </div>
  );
}
