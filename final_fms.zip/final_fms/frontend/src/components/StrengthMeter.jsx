import { evaluatePassword, strengthVariant } from "../utils/passwordPolicy.js";

export default function StrengthMeter({ password, showChecks = true }) {
  if (!password) return null;
  const { strength, checks } = evaluatePassword(password);
  const variant = strengthVariant[strength];
  const width = { "Not accepted": 15, Weak: 35, Medium: 65, Strong: 100 }[strength];
  return (
    <div className="mt-1">
      <div className="progress" style={{ height: 6 }}>
        <div className={`progress-bar bg-${variant}`} style={{ width: `${width}%` }} />
      </div>
      <small className={`text-${variant}`}>
        {strength === "Not accepted" ? "Password not accepted" : `${strength} password`}
      </small>
      {showChecks && strength === "Not accepted" && (
        <ul className="list-unstyled small mb-0 mt-1">
          {checks.map((c) => (
            <li key={c.label} className={c.ok ? "text-success" : "text-muted"}>
              <i className={`bi ${c.ok ? "bi-check-circle-fill" : "bi-circle"} me-1`} />
              {c.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
