import Modal from "./Modal.jsx";

export default function ConfirmModal({
  title = "Confirm",
  message,
  confirmLabel = "Yes",
  cancelLabel = "No",
  variant = "primary",
  busy = false,
  onConfirm,
  onCancel,
}) {
  return (
    <Modal
      title={title}
      onClose={onCancel}
      footer={
        <>
          <button className="btn btn-outline-secondary" onClick={onCancel} disabled={busy}>
            {cancelLabel}
          </button>
          <button className={`btn btn-${variant}`} onClick={onConfirm} disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2" />}
            {confirmLabel}
          </button>
        </>
      }
    >
      <p className="mb-0 fs-6">{message}</p>
    </Modal>
  );
}
