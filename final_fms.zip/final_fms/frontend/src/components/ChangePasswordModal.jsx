import { useState } from "react";
import Modal from "./Modal.jsx";
import Captcha, { makeCaptcha } from "./Captcha.jsx";
import StrengthMeter from "./StrengthMeter.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { authApi } from "../services/api.js";
import { errorMessage } from "../services/http.js";
import { evaluatePassword, PASSWORD_ERROR, PASSWORDS_DIFFERENT } from "../utils/passwordPolicy.js";

export default function ChangePasswordModal({ onClose }) {
  const { user, logout } = useAuth();
  const [form, setForm] = useState({ current: "", next: "", confirm: "", captcha: "" });
  const [captchaCode, setCaptchaCode] = useState(makeCaptcha);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const fail = (message) => {
    setError(message);
    setForm({ current: "", next: "", confirm: "", captcha: "" });
    setCaptchaCode(makeCaptcha());
  };

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!form.current || !form.next || !form.confirm || !form.captcha) return fail("All fields are mandatory");
    if (!evaluatePassword(form.next).accepted) return fail(PASSWORD_ERROR);
    if (form.next !== form.confirm) return fail(PASSWORDS_DIFFERENT);
    if (form.captcha.trim().toUpperCase() !== captchaCode) return fail("Captcha is incorrect");

    setBusy(true);
    try {
      await authApi.changePassword(user.username, form.current, form.next);
      logout("Password changed successfully, Please login again");
    } catch (err) {
      fail(errorMessage(err, "Could not change password"));
      setBusy(false);
    }
  }

  return (
    <Modal title="Change Password" onClose={onClose}>
      <form onSubmit={submit} noValidate>
        {error && <div className="alert alert-danger py-2" role="alert">{error}</div>}
        <div className="mb-3">
          <label className="form-label">Current Password</label>
          <input type="password" className="form-control" value={form.current} onChange={set("current")} autoComplete="current-password" />
        </div>
        <div className="mb-3">
          <label className="form-label">New Password</label>
          <input type="password" className="form-control" value={form.next} onChange={set("next")} autoComplete="new-password" />
          <StrengthMeter password={form.next} />
        </div>
        <div className="mb-3">
          <label className="form-label">Confirm Password</label>
          <input type="password" className="form-control" value={form.confirm} onChange={set("confirm")} autoComplete="new-password" />
          {form.confirm && form.confirm !== form.next && <small className="text-danger">Password doesn&apos;t match</small>}
        </div>
        <div className="mb-3">
          <label className="form-label">Captcha</label>
          <Captcha code={captchaCode} onRefresh={() => setCaptchaCode(makeCaptcha())} />
          <input className="form-control mt-2" placeholder="Type the characters shown" value={form.captcha} onChange={set("captcha")} autoComplete="off" maxLength={6} />
        </div>
        <div className="d-flex justify-content-end gap-2">
          <button type="button" className="btn btn-outline-secondary" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2" />}Change
          </button>
        </div>
      </form>
    </Modal>
  );
}
