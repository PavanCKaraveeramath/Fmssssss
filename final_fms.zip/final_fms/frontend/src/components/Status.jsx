import { SEVERITY_COLORS, severityText } from "../utils/format.js";

const bootstrap = {
  Activated: "success",
  Deactivated: "secondary",
  OPEN: "primary",
  ACKNOWLEDGED: "info",
  CLEARED: "success",
  TERMINATED: "secondary",
};

export default function Status({ value }) {
  if (SEVERITY_COLORS[value]) {
    return (
      <span className="badge" style={{ background: SEVERITY_COLORS[value], color: severityText(value) }}>
        {value}
      </span>
    );
  }
  return <span className={`badge text-bg-${bootstrap[value] || "secondary"}`}>{value}</span>;
}
