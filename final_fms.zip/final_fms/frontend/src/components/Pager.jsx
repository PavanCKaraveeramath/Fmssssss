export default function Pager({ page, size, count, totalPages, totalElements, noun, onChange }) {
  const from = totalElements ? page * size + 1 : 0;
  const to = page * size + count;
  return (
    <div className="pagination-bar">
      <span>{totalElements ? `Showing ${from}-${to} of ${totalElements} ${noun}` : `Showing 0 ${noun}`}</span>
      <div className="pagination-controls">
        <button className="btn btn-outline-secondary btn-sm" type="button" disabled={page <= 0} onClick={() => onChange(page - 1)}>
          Previous
        </button>
        <span aria-live="polite">
          Page {totalPages ? page + 1 : 0} of {totalPages}
        </span>
        <button
          className="btn btn-outline-secondary btn-sm"
          type="button"
          disabled={page >= totalPages - 1}
          onClick={() => onChange(page + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
}
