export const SEVERITY_COLORS = {
  CLEAR: "#28a745",
  WARNING: "#fd7e14",
  MAJOR: "#ffc107",
  SEVERE: "#6f42c1",
  CRITICAL: "#dc3545",
};
export const STATUS_COLORS = {
  OPEN: "#0d6efd",
  ACKNOWLEDGED: "#20c997",
  CLEARED: "#28a745",
  TERMINATED: "#6c757d",
};
export const severityText = (sev) => (sev === "MAJOR" ? "#212529" : "#ffffff");

export function hexToRgba(hex, alpha) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}
