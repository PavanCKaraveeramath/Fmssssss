// Keep these rules aligned with backend PasswordPolicy.

export const PASSWORD_ERROR = "Password Requirement is not matched";
export const PASSWORDS_DIFFERENT = "Password provided are not same";
export const ALLOWED_SPECIALS = "@#$%&*!^";

export function evaluatePassword(pw = "") {
  const checks = [
    { label: "At least 4 characters", ok: pw.length >= 4 },
    { label: "An uppercase letter", ok: /[A-Z]/.test(pw) },
    { label: "A lowercase letter", ok: /[a-z]/.test(pw) },
    { label: "A number", ok: /[0-9]/.test(pw) },
    { label: `A special character (${ALLOWED_SPECIALS.split("").join(" ")})`, ok: /[@#$%&*!^]/.test(pw) },
    { label: "No other characters", ok: pw.length > 0 && /^[A-Za-z0-9@#$%&*!^]+$/.test(pw) },
  ];
  const accepted = pw.length > 3 && checks.every((c) => c.ok);
  let strength = "Not accepted";
  if (accepted) strength = pw.length <= 6 ? "Weak" : pw.length <= 8 ? "Medium" : "Strong";
  return { accepted, strength, checks };
}

export const strengthVariant = { "Not accepted": "danger", Weak: "warning", Medium: "info", Strong: "success" };
