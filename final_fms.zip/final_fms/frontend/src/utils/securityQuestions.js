export const SECURITY_QUESTIONS = [
  "What is your favorite color?",
  "What is the name of your first pet?",
  "What was the name of your first school?",
];
