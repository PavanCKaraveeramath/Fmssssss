export const IP_ERROR = "Enter a valid IP address";

export function isValidIp(ip) {
  if (typeof ip !== "string" || !ip) return false;
  const parts = ip.split(".");
  if (parts.length !== 4) return false;
  const o = [];
  for (const p of parts) {
    if (!/^[0-9]{1,3}$/.test(p)) return false;
    if (p.length > 1 && p[0] === "0") return false;
    const n = Number(p);
    if (n > 255) return false;
    o.push(n);
  }
  if (o[0] === 0 || o[0] === 127 || (o[0] === 169 && o[1] === 254) || o[0] >= 224) return false;
  return true;
}
