import { Navigate, Route, Routes } from "react-router-dom";
import { HOME_BY_ROLE, useAuth } from "./context/AuthContext.jsx";
import Guard from "./routes/Guard.jsx";
import Layout from "./components/Layout.jsx";
import Login from "./pages/Login.jsx";
import Forgot from "./pages/Forgot.jsx";
import Users from "./pages/admin/Users.jsx";
import AddUser from "./pages/admin/AddUser.jsx";
import Devices from "./pages/operator/Devices.jsx";
import AddDevice from "./pages/operator/AddDevice.jsx";
import Faults from "./pages/manager/Faults.jsx";
import Reports from "./pages/Reports.jsx";

function Home() {
  const { user } = useAuth();
  return <Navigate replace to={HOME_BY_ROLE[user.role]} />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/forgot-password" element={<Forgot />} />
      <Route element={<Guard />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />

          <Route element={<Guard roles={["ADMIN"]} />}>
            <Route path="/admin" element={<Navigate to="/admin/users" replace />} />
            <Route path="/admin/users" element={<Users mode="view" />} />
            <Route path="/admin/users/new" element={<AddUser />} />
            <Route path="/admin/change-role" element={<Users mode="role" />} />
            <Route path="/admin/delete-user" element={<Users mode="delete" />} />
            <Route path="/admin/reports" element={<Reports />} />
          </Route>

          <Route element={<Guard roles={["OPERATOR"]} />}>
            <Route path="/operator" element={<Navigate to="/operator/devices" replace />} />
            <Route path="/operator/devices" element={<Devices mode="view" />} />
            <Route path="/operator/devices/new" element={<AddDevice />} />
            <Route path="/operator/edit-device" element={<Devices mode="edit" />} />
            <Route path="/operator/delete-device" element={<Devices mode="delete" />} />
            <Route path="/operator/reports" element={<Reports />} />
          </Route>

          <Route element={<Guard roles={["MANAGER"]} />}>
            <Route path="/manager" element={<Navigate to="/manager/faults" replace />} />
            <Route path="/manager/faults" element={<Faults />} />
            <Route path="/manager/reports" element={<Reports />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
