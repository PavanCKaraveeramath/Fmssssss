const KEY = "fm.session";

export function readSession() {
  try {
    return JSON.parse(sessionStorage.getItem(KEY) || "null");
  } catch {
    return null;
  }
}
export function writeSession(session) {
  sessionStorage.setItem(KEY, JSON.stringify(session));
}
export function clearSession() {
  sessionStorage.clear();
  localStorage.clear();
}
