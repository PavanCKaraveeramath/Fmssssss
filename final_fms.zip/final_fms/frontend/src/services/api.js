import { http } from "./http.js";


export const authApi = {
  login: (username, password) =>
    http.post("/api/auth/login", { username, password }).then((r) => r.data),
  changePassword: (username, currentPassword, newPassword) =>
    http
      .post("/api/auth/change-password", { username, currentPassword, newPassword })
      .then((r) => r.data),
  getQuestion: (username) =>
    http.post("/api/auth/forgot-password/get-question", { username }).then((r) => r.data),
  resetPassword: (username, securityAnswer, newPassword) =>
    http
      .post("/api/auth/forgot-password/reset", { username, securityAnswer, newPassword })
      .then((r) => r.data),
};

export const adminApi = {
  listUsers: (page = 0, size = 10) =>
    http.get("/api/admin/users", { params: { page, size } }).then((r) => r.data),
  addUser: (payload) => http.post("/api/admin/users", payload).then((r) => r.data),
  changeRole: (username, role) =>
    http.put(`/api/admin/users/${encodeURIComponent(username)}/role`, { role }).then((r) => r.data),
  deleteUser: (userId) => http.delete(`/api/admin/users/${userId}`).then((r) => r.data),
};

export const deviceApi = {
  list: (page = 0, size = 10) =>
    http.get("/api/operator/devices", { params: { page, size } }).then((r) => r.data),
  add: (payload) => http.post("/api/operator/devices", payload).then((r) => r.data),
  updateIp: (serialNumber, ipAddress) =>
    http
      .put(`/api/operator/devices/${encodeURIComponent(serialNumber)}`, { ipAddress })
      .then((r) => r.data),
  deactivate: (serialNumber) =>
    http.delete(`/api/operator/devices/${encodeURIComponent(serialNumber)}`).then((r) => r.data),
};

export const faultApi = {
  list: (params) => http.get("/api/manager/faults", { params }).then((r) => r.data),
  acknowledge: (ids) => http.post("/api/manager/faults/acknowledge", { ids }).then((r) => r.data),
  clear: (ids) => http.post("/api/manager/faults/clear", { ids }).then((r) => r.data),
  terminate: (ids) => http.post("/api/manager/faults/terminate", { ids }).then((r) => r.data),
  updateNotes: (id, notes) =>
    http.put(`/api/manager/faults/${id}/notes`, { notes }).then((r) => r.data),
};

export const reportApi = {
  bySeverity: () => http.get("/api/manager/reports/by-severity").then((r) => r.data),
  byStatus: () => http.get("/api/manager/reports/by-status").then((r) => r.data),
};
