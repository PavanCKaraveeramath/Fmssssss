import axios from "axios";
import { readSession } from "./session.js";

export const http = axios.create({
  baseURL: (import.meta.env.VITE_API_BASE_URL || "http://localhost:8080").replace(/\/api\/?$/, ""),
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
});

http.interceptors.request.use((config) => {
  const session = readSession();
  if (session?.token) config.headers.Authorization = `Bearer ${session.token}`;
  return config;
});

http.interceptors.response.use(
  (response) => response,
  (error) => {
    const url = error.config?.url || "";
    if (error.response?.status === 401 && !url.includes("/api/auth/login")) {
      window.dispatchEvent(new Event("fm:unauthorized"));
    }
    return Promise.reject(error);
  },
);

export function errorMessage(error, fallback = "Something went wrong") {
  if (error.response?.data?.message) return error.response.data.message;
  if (error.request && !error.response) return "Cannot reach the server. Is the backend running on port 8080?";
  return fallback;
}
