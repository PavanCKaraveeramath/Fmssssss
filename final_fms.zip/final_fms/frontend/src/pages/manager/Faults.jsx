import { useCallback, useEffect, useState } from "react";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import Feedback from "../../components/Feedback.jsx";
import Modal from "../../components/Modal.jsx";
import Pager from "../../components/Pager.jsx";
import Status from "../../components/Status.jsx";
import { faultApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";
import { SEVERITY_COLORS, hexToRgba } from "../../utils/format.js";
import NotesModal from "./NotesModal.jsx";

const PAGE_SIZE = 10;
const REFRESH_MS = 30000;

const ACTION_LABEL = { acknowledge: "Acknowledge", clear: "Clear", terminate: "Terminate" };

export default function Faults() {
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(0);
  const [data, setData] = useState({ content: [], totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);
  const [selected, setSelected] = useState(() => new Set());
  const [dialog, setDialog] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => {
      setQuery(search.trim());
      setPage(0);
    }, 350);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      try {
        const res = await faultApi.list({ search: query || undefined, page, size: PAGE_SIZE });
        if (res.content.length === 0 && page > 0) {
          setPage(page - 1);
          return;
        }
        setData(res);
        setErr("");
        setLastUpdated(new Date());
        const visible = new Set(res.content.map((a) => a.id));
        setSelected((prev) => new Set([...prev].filter((id) => visible.has(id))));
      } catch (e) {
        if (!silent) setErr(errorMessage(e, "Could not load faults"));
      } finally {
        setLoading(false);
      }
    },
    [query, page],
  );

  useEffect(() => {
    load();
    const timer = setInterval(() => load(true), REFRESH_MS);
    return () => clearInterval(timer);
  }, [load]);

  const toggle = (id) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  const allSelected = data.content.length > 0 && data.content.every((a) => selected.has(a.id));
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(data.content.map((a) => a.id)));
  const selectedAlarms = data.content.filter((a) => selected.has(a.id));

  function request(action, alarms) {
    if (!alarms.length) return;
    const warn = (message) => setDialog({ type: "warn", message });
    if (action === "acknowledge" && alarms.some((a) => a.status !== "OPEN")) return warn("Only open faults can be acknowledged");
    if (action === "clear" && alarms.some((a) => a.status === "OPEN")) return warn("Only acknowledged fault should be cleared");
    if (action === "clear" && alarms.some((a) => a.status === "CLEARED")) return warn("Fault is already cleared");
    if (action === "terminate" && alarms.some((a) => a.status === "OPEN")) return warn("Only acknowledged or cleared fault can be terminated");
    setDialog({ type: "confirm", action, alarms });
  }

  async function execute() {
    const { action, alarms } = dialog;
    setBusy(true);
    try {
      const res = await faultApi[action](alarms.map((a) => a.id));
      setOk(res.message);
      setErr("");
      setSelected(new Set());
      setDialog(null);
      await load(true);
    } catch (e) {
      setDialog({ type: "warn", message: errorMessage(e, "Action failed") });
    } finally {
      setBusy(false);
    }
  }

  const noteSaved = (message) => {
    setDialog(null);
    setOk(message);
    load(true);
  };
  const noteFailed = (message) => {
    setDialog(null);
    setErr(message);
  };

  return (
    <>
      <div className="heading">
        <div>
          <h1>Fault handling</h1>
          <p>Review alarms and manage the fault lifecycle.</p>
        </div>
        <button className="btn btn-outline-secondary" onClick={() => load()}>
          <i className="bi bi-arrow-clockwise me-1" />Refresh
        </button>
      </div>

      <Feedback error={err} success={ok} />

      <div className="panel">
        <div className="panel-head filters">
          <b>Fault events</b>
          <input
            className="form-control search"
            placeholder="Search by IP, serial number or trap name"
            aria-label="Search faults"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <small className="text-muted">
            Auto-refresh every 30 s{lastUpdated && <> · updated {lastUpdated.toLocaleTimeString()}</>}
          </small>
          <div className="btn-group ms-auto">
            <button className="btn btn-sm btn-outline-primary" disabled={!selectedAlarms.length} onClick={() => request("acknowledge", selectedAlarms)}>ACK selected</button>
            <button className="btn btn-sm btn-outline-success" disabled={!selectedAlarms.length} onClick={() => request("clear", selectedAlarms)}>Clear selected</button>
            <button className="btn btn-sm btn-outline-danger" disabled={!selectedAlarms.length} onClick={() => request("terminate", selectedAlarms)}>Terminate selected</button>
          </div>
        </div>

        <div className="severity-key">
          {Object.entries(SEVERITY_COLORS).map(([sev, color]) => (
            <span key={sev}>
              <i style={{ background: color }} />
              {sev}
            </span>
          ))}
        </div>

        <div className="table-responsive">
          <table className="table mb-0 align-middle">
            <thead>
              <tr>
                <th style={{ width: 36 }}>
                  <input type="checkbox" className="form-check-input" checked={allSelected} onChange={toggleAll} aria-label="Select all faults" />
                </th>
                <th>Device IP</th>
                <th>Serial Nos</th>
                <th>Device Type</th>
                <th>Severity</th>
                <th>Status</th>
                <th>Trap</th>
                <th>Notes</th>
                <th className="text-center">Occurrence</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan={10} className="text-center py-4"><span className="spinner-border spinner-border-sm" /></td></tr>}
              {!loading && data.content.map((a) => {
                const color = SEVERITY_COLORS[a.severity];
                return (
                  <tr key={a.id} style={{ "--bs-table-bg": hexToRgba(color, 0.14) }}>
                    <td style={{ borderLeft: `6px solid ${color}` }}>
                      <input type="checkbox" className="form-check-input" checked={selected.has(a.id)} onChange={() => toggle(a.id)} aria-label={`Select fault ${a.id}`} />
                    </td>
                    <td>{a.deviceIp}</td>
                    <td>{a.serialNumber}</td>
                    <td>{a.deviceType || "-"}</td>
                    <td><Status value={a.severity} /></td>
                    <td><Status value={a.status} /></td>
                    <td>{a.alarmName}</td>
                    <td>
                      <span className="me-1">{a.notes || "-"}</span>
                      <button className="btn btn-link btn-sm p-0" onClick={() => setDialog({ type: "notes", alarm: a })} title="Edit notes" aria-label="Edit notes">
                        <i className="bi bi-pencil" />
                      </button>
                    </td>
                    <td className="text-center">{a.occurrenceCount ?? 1}</td>
                    <td>
                      <div className="d-flex gap-1 flex-wrap">
                        <button className="btn btn-sm btn-secondary" disabled={a.status !== "OPEN"} onClick={() => request("acknowledge", [a])}>ACK</button>
                        <button className="btn btn-sm btn-success" disabled={a.status === "CLEARED"} onClick={() => request("clear", [a])}>clear</button>
                        <button className="btn btn-sm btn-danger" onClick={() => request("terminate", [a])}>Terminate</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!loading && !data.content.length && (
            <p className="empty">No active faults{query && " match your search"}. New simulator alarms arrive every minute.</p>
          )}
        </div>
        <Pager page={page} size={PAGE_SIZE} count={data.content.length} totalPages={data.totalPages} totalElements={data.totalElements} noun="faults" onChange={setPage} />
      </div>

      {dialog?.type === "confirm" && (
        <ConfirmModal
          title={`${ACTION_LABEL[dialog.action]} fault`}
          message={`Are you sure you want to ${dialog.action} ${dialog.alarms.length === 1 ? "this fault" : `${dialog.alarms.length} faults`}?`}
          confirmLabel="OK"
          cancelLabel="Cancel"
          variant={dialog.action === "terminate" ? "danger" : "primary"}
          busy={busy}
          onConfirm={execute}
          onCancel={() => setDialog(null)}
        />
      )}
      {dialog?.type === "warn" && (
        <Modal title="Action not allowed" onClose={() => setDialog(null)} footer={<button className="btn btn-primary" onClick={() => setDialog(null)}>OK</button>}>
          <p className="mb-0"><i className="bi bi-exclamation-triangle-fill text-warning me-2" />{dialog.message}</p>
        </Modal>
      )}
      {dialog?.type === "notes" && <NotesModal alarm={dialog.alarm} onClose={() => setDialog(null)} onSaved={noteSaved} onError={noteFailed} />}
    </>
  );
}
