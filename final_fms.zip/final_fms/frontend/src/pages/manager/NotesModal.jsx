import { useState } from "react";
import Modal from "../../components/Modal.jsx";
import { faultApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";

export default function NotesModal({ alarm, onClose, onSaved, onError }) {
  const [notes, setNotes] = useState(alarm.notes || "");
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    try {
      const res = await faultApi.updateNotes(alarm.id, notes);
      onSaved(res.message);
    } catch (err) {
      onError(errorMessage(err, "Could not save notes"));
    }
  }

  return (
    <Modal
      title={`Notes - ${alarm.alarmName} (${alarm.serialNumber})`}
      onClose={onClose}
      footer={
        <>
          <button className="btn btn-outline-secondary" onClick={onClose} disabled={busy}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2" />}Save
          </button>
        </>
      }
    >
      <textarea className="form-control" rows={4} maxLength={500} value={notes} onChange={(e) => setNotes(e.target.value)} autoFocus />
      <small className="text-muted">{notes.length}/500</small>
    </Modal>
  );
}
