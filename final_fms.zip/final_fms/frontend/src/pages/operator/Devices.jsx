import { useCallback, useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Feedback from "../../components/Feedback.jsx";
import Pager from "../../components/Pager.jsx";
import { deviceApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";
import DeactivateDeviceModal from "./DeactivateDeviceModal.jsx";
import EditDeviceModal from "./EditDeviceModal.jsx";

const PAGE_SIZE = 10;

const TITLES = {
  view: ["Device list", "Active devices configured for monitoring."],
  edit: ["Edit device", "Only the IP address can be changed."],
  delete: ["Delete device", "Deleting deactivates the device; it stops raising faults."],
};

export default function Devices({ mode = "view" }) {
  const location = useLocation();
  const [page, setPage] = useState(0);
  const [data, setData] = useState({ content: [], totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState(location.state?.ok || "");
  const [editDevice, setEditDevice] = useState(null);
  const [deleteDevice, setDeleteDevice] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await deviceApi.list(page, PAGE_SIZE);
      if (res.content.length === 0 && page > 0) setPage(page - 1);
      else setData(res);
    } catch (e) {
      setErr(errorMessage(e, "Could not load devices"));
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => {
    load();
  }, [load]);

  const done = (message) => {
    setEditDevice(null);
    setDeleteDevice(null);
    setErr("");
    setOk(message);
    load();
  };
  const failed = (message) => {
    setEditDevice(null);
    setDeleteDevice(null);
    setOk("");
    setErr(message);
  };
  const cancelled = (message) => {
    setEditDevice(null);
    setErr("");
    setOk(message);
  };

  const [title, subtitle] = TITLES[mode];
  const cols = mode === "view" ? 3 : 4;

  return (
    <>
      <div className="heading">
        <div>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
      </div>
      <Feedback error={err} success={ok} />
      <div className="panel">
        <div className="panel-head">
          <b>Devices</b>
        </div>
        <div className="table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th>Device serial number</th>
                <th>Device IP</th>
                <th>Device type</th>
                {mode !== "view" && <th>Action</th>}
              </tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan={cols} className="text-center py-4"><span className="spinner-border spinner-border-sm" /></td></tr>}
              {!loading && data.content.map((d) => (
                <tr key={d.id}>
                  <td>{d.serialNumber}</td>
                  <td>{d.ipAddress}</td>
                  <td>{d.deviceType.toUpperCase()}</td>
                  {mode === "edit" && (
                    <td>
                      <button className="btn btn-sm btn-outline-primary" onClick={() => setEditDevice(d)}>
                        <i className="bi bi-pencil-square me-1" />Edit
                      </button>
                    </td>
                  )}
                  {mode === "delete" && (
                    <td>
                      <button className="btn btn-sm btn-outline-danger" onClick={() => setDeleteDevice(d)}>
                        <i className="bi bi-trash me-1" />Delete
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!loading && !data.content.length && <p className="empty">No active devices configured.</p>}
        </div>
        <Pager page={page} size={PAGE_SIZE} count={data.content.length} totalPages={data.totalPages} totalElements={data.totalElements} noun="devices" onChange={setPage} />
      </div>
      {editDevice && <EditDeviceModal device={editDevice} onClose={() => setEditDevice(null)} onDone={done} onCancelled={cancelled} />}
      {deleteDevice && <DeactivateDeviceModal device={deleteDevice} onClose={() => setDeleteDevice(null)} onDone={done} onError={failed} />}
    </>
  );
}
