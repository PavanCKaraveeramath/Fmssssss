import { useState } from "react";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import { deviceApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";

export default function DeactivateDeviceModal({ device, onClose, onDone, onError }) {
  const [busy, setBusy] = useState(false);

  async function deactivate() {
    setBusy(true);
    try {
      const res = await deviceApi.deactivate(device.serialNumber);
      onDone(res.message);
    } catch (err) {
      onError(errorMessage(err, "Could not deactivate the device"));
    }
  }

  return (
    <ConfirmModal
      title="Delete device"
      message={`Are you sure you want to delete ${device.serialNumber}?`}
      confirmLabel="Okay"
      cancelLabel="Cancel"
      variant="danger"
      busy={busy}
      onConfirm={deactivate}
      onCancel={onClose}
    />
  );
}
