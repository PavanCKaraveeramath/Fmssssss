import { useState } from "react";
import Modal from "../../components/Modal.jsx";
import { deviceApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";
import { IP_ERROR, isValidIp } from "../../utils/ipValidator.js";

export default function EditDeviceModal({ device, onClose, onDone, onCancelled }) {
  const [ip, setIp] = useState(device.ipAddress);
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);

  function submit(e) {
    e.preventDefault();
    const value = ip.trim();
    if (!value) return setError("THIS FIELD IS MANDATORY");
    if (!isValidIp(value)) return setError(IP_ERROR);
    setError("");
    setConfirming(true);
  }

  async function confirm() {
    if (!checked) return onCancelled("No changes were made");
    setBusy(true);
    try {
      const res = await deviceApi.updateIp(device.serialNumber, ip.trim());
      onDone(res.message);
    } catch (err) {
      setConfirming(false);
      setBusy(false);
      setError(errorMessage(err, "Could not update the device"));
    }
  }

  if (confirming) {
    return (
      <Modal
        title="Confirm update"
        onClose={onClose}
        footer={
          <>
            <button className="btn btn-outline-secondary" onClick={onClose} disabled={busy}>Cancel</button>
            <button className="btn btn-primary" onClick={confirm} disabled={busy}>
              {busy && <span className="spinner-border spinner-border-sm me-2" />}Submit
            </button>
          </>
        }
      >
        <p>
          Update the IP address of <strong>{device.serialNumber}</strong> from <code>{device.ipAddress}</code> to <code>{ip.trim()}</code>?
        </p>
        <div className="form-check">
          <input id="confirm-update" className="form-check-input" type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} />
          <label className="form-check-label" htmlFor="confirm-update">Yes, I confirm to update this device</label>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title="Edit device" onClose={onClose}>
      <form onSubmit={submit} noValidate>
        <div className="mb-3">
          <label className="form-label">Device serial number</label>
          <input className="form-control" value={device.serialNumber} readOnly disabled />
        </div>
        <div className="mb-3">
          <label className="form-label">Device IP address</label>
          <input className={`form-control ${error ? "is-invalid" : ""}`} value={ip} onChange={(e) => setIp(e.target.value)} autoFocus />
          {error && <div className="invalid-feedback">{error}</div>}
        </div>
        <div className="mb-3">
          <label className="form-label">Device type</label>
          <input className="form-control" value={device.deviceType} readOnly disabled />
        </div>
        <div className="d-flex justify-content-end gap-2">
          <button type="button" className="btn btn-outline-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary">Submit</button>
        </div>
      </form>
    </Modal>
  );
}
