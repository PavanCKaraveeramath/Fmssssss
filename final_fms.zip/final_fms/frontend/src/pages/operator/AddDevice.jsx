import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Feedback from "../../components/Feedback.jsx";
import { deviceApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";
import { IP_ERROR, isValidIp } from "../../utils/ipValidator.js";

const TYPES = ["Router", "Switch", "Hub"];
const MANDATORY = "THIS FIELD IS MANDATORY";

export default function AddDevice() {
  const nav = useNavigate();
  const [f, setF] = useState({ serialNumber: "", ipAddress: "", deviceType: "" });
  const [errors, setErrors] = useState({});
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (e) => setF({ ...f, [e.target.name]: e.target.value });
  const cls = (n) => `form-control ${errors[n] ? "is-invalid" : ""}`;

  function validate() {
    const e = {};
    if (!f.serialNumber.trim()) e.serialNumber = MANDATORY;
    else if (!/^[A-Za-z0-9_-]{3,50}$/.test(f.serialNumber.trim())) e.serialNumber = "3-50 characters: letters, digits, - or _";
    if (!f.ipAddress.trim()) e.ipAddress = MANDATORY;
    else if (!isValidIp(f.ipAddress.trim())) e.ipAddress = `${IP_ERROR} (0.0.0.0, 255.255.255.255 and subnet masks are not allowed)`;
    if (!f.deviceType) e.deviceType = MANDATORY;
    return e;
  }

  async function go(ev) {
    ev.preventDefault();
    setErr("");
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const res = await deviceApi.add({
        serialNumber: f.serialNumber.trim(),
        ipAddress: f.ipAddress.trim(),
        deviceType: f.deviceType,
      });
      nav("/operator/devices", { state: { ok: res.message } });
    } catch (error) {
      const msg = errorMessage(error, "Could not add device");
      if (/serial/i.test(msg)) setErrors({ serialNumber: msg });
      else if (/ip/i.test(msg)) setErrors({ ipAddress: msg });
      else setErr(msg);
      setBusy(false);
    }
  }

  return (
    <>
      <div className="heading">
        <div>
          <h1>Add device</h1>
          <p>Configure a device for fault monitoring.</p>
        </div>
      </div>
      <Feedback error={err} />
      <div className="panel p-4" style={{ maxWidth: 600 }}>
        <form onSubmit={go} noValidate>
          <div className="mb-3">
            <label className="form-label">Device serial number</label>
            <input name="serialNumber" className={cls("serialNumber")} value={f.serialNumber} onChange={set} autoComplete="off" />
            {errors.serialNumber && <div className="invalid-feedback">{errors.serialNumber}</div>}
          </div>
          <div className="mb-3">
            <label className="form-label">Device IP address</label>
            <input name="ipAddress" className={cls("ipAddress")} placeholder="e.g. 10.0.0.25" value={f.ipAddress} onChange={set} autoComplete="off" />
            {errors.ipAddress && <div className="invalid-feedback">{errors.ipAddress}</div>}
          </div>
          <div className="mb-4">
            <label className="form-label">Device type</label>
            <select name="deviceType" className={`form-select ${errors.deviceType ? "is-invalid" : ""}`} value={f.deviceType} onChange={set}>
              <option value="">Choose the device type</option>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
            {errors.deviceType && <div className="invalid-feedback">{errors.deviceType}</div>}
          </div>
          <button className="btn btn-primary" disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2" />}Add device
          </button>
        </form>
      </div>
    </>
  );
}
