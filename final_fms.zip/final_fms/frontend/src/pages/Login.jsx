import { useEffect, useState } from "react";
import { Link, Navigate, useLocation } from "react-router-dom";
import { HOME_BY_ROLE, useAuth } from "../context/AuthContext.jsx";
import Feedback from "../components/Feedback.jsx";
import { errorMessage } from "../services/http.js";

export default function Login() {
  const { user, login } = useAuth();
  const loc = useLocation();
  const flash = loc.state;
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!flash?.loggedOut) return undefined;
    window.history.pushState(null, "", window.location.href);
    const stay = () => window.history.pushState(null, "", window.location.href);
    window.addEventListener("popstate", stay);
    return () => window.removeEventListener("popstate", stay);
  }, [flash]);

  if (user) return <Navigate to={HOME_BY_ROLE[user.role]} replace />;

  async function go(e) {
    e.preventDefault();
    setErr("");
    if (!username.trim() || !password) return setErr("Username and password are mandatory");
    setBusy(true);
    try {
      await login(username.trim(), password);
    } catch (error) {
      setErr(errorMessage(error, "Login failed"));
      setBusy(false);
    }
  }

  const ok = flash?.type !== "danger" && flash?.type !== "warning" ? flash?.message : "";
  const warn = flash?.type === "danger" || flash?.type === "warning" ? flash?.message : "";

  return (
    <div className="login">
      <section className="login-art">
        <div className="brand login-brand"><span className="brand-mark"><i className="bi bi-broadcast-pin" aria-hidden="true" /></span>Fault Management System</div>
        <div className="pitch">
          <small className="pitch-kicker"><span /> NETWORK OPERATIONS</small>
          <h1>
            See the signal.
            <br />
            <span>Resolve the fault.</span>
          </h1>
          <p>Network device monitoring, alarm visibility and fault lifecycle management.</p>
        </div>
        <div className="login-team">
          <div className="login-team-title"><i className="bi bi-people" aria-hidden="true" /> PROJECT TEAM</div>
          <ul>
            <li>Pavan C Karaveeramath</li>
            <li>Md Pervaiz Akram</li>
            <li>Divya Joshi</li>
            <li>Madhuri Kadam</li>
            <li>Manish Singh</li>
          </ul>
        </div>
        <div className="login-art-footer"><span className="status-dot" /> Operations workspace <span className="footer-divider">/</span> Secure access</div>
      </section>
      <section className="login-panel">
        <div className="login-box">
          <div className="login-heading-mark"><i className="bi bi-shield-lock" aria-hidden="true" /></div>
          <small className="eyebrow">WELCOME BACK</small>
          <h2>Sign in to your workspace</h2>
          <p className="text-secondary">Use your assigned account to continue.</p>
          <Feedback error={err || warn} success={!err && !warn ? ok : ""} />
          <form onSubmit={go} noValidate>
            <label className="form-label" htmlFor="username">Username</label>
            <div className="login-input-wrap mb-3"><i className="bi bi-person" aria-hidden="true" /><input id="username" className="form-control" autoFocus autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} /></div>
            <label className="form-label" htmlFor="password">Password</label>
            <div className="login-input-wrap login-password-wrap mb-2"><i className="bi bi-key" aria-hidden="true" /><input id="password" type={showPassword ? "text" : "password"} className="form-control" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /><button className="password-toggle" type="button" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? "Hide password" : "Show password"} aria-pressed={showPassword}><i className={`bi ${showPassword ? "bi-eye-slash" : "bi-eye"}`} aria-hidden="true" /></button></div>
            <div className="text-end mb-4">
              <Link to="/forgot-password">Forgot Password?</Link>
            </div>
            <button className="btn btn-primary w-100 login-submit" disabled={busy}>
              {busy ? <><span className="spinner-border spinner-border-sm me-2" />Signing in</> : <>Sign in <i className="bi bi-arrow-right ms-2" aria-hidden="true" /></>}
            </button>
          </form>
          <div className="demo mt-4" aria-label="Demo accounts">
            <div className="demo-title"><i className="bi bi-info-circle" aria-hidden="true" /> Demo access</div>
            <div className="demo-account"><span>Administrator</span><code>admin / Admin123!</code></div>
            <div className="demo-account"><span>Operator</span><code>operator / Operator123!</code></div>
            <div className="demo-account"><span>Manager</span><code>manager / Manager123!</code></div>
          </div>
          <div className="login-security"><i className="bi bi-lock-fill" aria-hidden="true" /> Your session is protected with secure authentication</div>
        </div>
      </section>
    </div>
  );
}
