import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Feedback from "../components/Feedback.jsx";
import StrengthMeter from "../components/StrengthMeter.jsx";
import { authApi } from "../services/api.js";
import { errorMessage } from "../services/http.js";
import { evaluatePassword, PASSWORD_ERROR, PASSWORDS_DIFFERENT } from "../utils/passwordPolicy.js";

export default function Forgot() {
  const nav = useNavigate();
  const [step, setStep] = useState(1);
  const [username, setUsername] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [pw, setPw] = useState({ next: "", confirm: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function findUser(e) {
    e.preventDefault();
    setErr("");
    if (!username.trim()) return setErr("Username is mandatory");
    setBusy(true);
    try {
      const res = await authApi.getQuestion(username.trim());
      setQuestion(res.data.securityQuestion);
      setStep(2);
    } catch (error) {
      if (error.response?.status === 404) {
        nav("/login", { replace: true, state: { message: "User does not exist", type: "danger" } });
        return;
      }
      setErr(errorMessage(error));
    } finally {
      setBusy(false);
    }
  }

  function takeAnswer(e) {
    e.preventDefault();
    if (!answer.trim()) return setErr("Answer is mandatory");
    setErr("");
    setStep(3);
  }

  async function reset(e) {
    e.preventDefault();
    setErr("");
    if (!evaluatePassword(pw.next).accepted) return setErr(PASSWORD_ERROR);
    if (pw.next !== pw.confirm) return setErr(PASSWORDS_DIFFERENT);
    setBusy(true);
    try {
      await authApi.resetPassword(username.trim(), answer, pw.next);
      nav("/login", { replace: true, state: { message: "Password reset successfully. Please login.", type: "success" } });
    } catch (error) {
      const msg = errorMessage(error);
      if (error.response?.status === 400 && /answer/i.test(msg)) {
        setAnswer("");
        setStep(2);
      }
      setErr(msg);
      setBusy(false);
    }
  }

  return (
    <div className="login">
      <section className="login-art">
        <div className="brand">◈ Fault Management System</div>
        <div className="pitch">
          <small>ACCOUNT RECOVERY</small>
          <h1>
            Locked out?
            <br />
            <span>Reset in three steps.</span>
          </h1>
        </div>
      </section>
      <section className="login-panel">
        <div className="login-box">
          <small className="eyebrow">STEP {step} OF 3</small>
          <h2>Forgot password</h2>
          <Feedback error={err} />

          {step === 1 && (
            <form onSubmit={findUser} noValidate>
              <label className="form-label" htmlFor="fp-user">Enter your username</label>
              <input id="fp-user" className="form-control mb-3" autoFocus value={username} onChange={(e) => setUsername(e.target.value)} />
              <button className="btn btn-primary w-100" disabled={busy}>
                {busy && <span className="spinner-border spinner-border-sm me-2" />}Continue
              </button>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={takeAnswer} noValidate>
              <label className="form-label">Security question</label>
              <div className="security-question mb-2">{question}</div>
              <input className="form-control mb-3" autoFocus placeholder="Your answer" value={answer} onChange={(e) => setAnswer(e.target.value)} />
              <button className="btn btn-primary w-100">Continue</button>
            </form>
          )}

          {step === 3 && (
            <form onSubmit={reset} noValidate>
              <label className="form-label">New password</label>
              <input type="password" className="form-control" autoFocus autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
              <StrengthMeter password={pw.next} />
              <label className="form-label mt-3">Confirm new password</label>
              <input type="password" className="form-control mb-3" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
              <button className="btn btn-primary w-100" disabled={busy}>
                {busy && <span className="spinner-border spinner-border-sm me-2" />}Reset password
              </button>
            </form>
          )}

          <div className="text-center mt-3">
            <Link to="/login">Back to login</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
