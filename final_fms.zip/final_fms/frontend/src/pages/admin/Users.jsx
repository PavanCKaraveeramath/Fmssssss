import { useCallback, useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Feedback from "../../components/Feedback.jsx";
import Pager from "../../components/Pager.jsx";
import Status from "../../components/Status.jsx";
import { adminApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";
import ChangeRoleModal from "./ChangeRoleModal.jsx";
import DeleteUserModal from "./DeleteUserModal.jsx";

const PAGE_SIZE = 10;

const TITLES = {
  view: ["User details", "All registered users and their roles."],
  role: ["Change role", "Pick a user and change their role."],
  delete: ["Delete user", "Deleting deactivates the account; the record is kept."],
};

export default function Users({ mode = "view" }) {
  const location = useLocation();
  const [page, setPage] = useState(0);
  const [data, setData] = useState({ content: [], totalPages: 0, totalElements: 0 });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState(location.state?.ok || "");
  const [roleUser, setRoleUser] = useState(null);
  const [deleteUser, setDeleteUser] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await adminApi.listUsers(page, PAGE_SIZE);
      if (res.content.length === 0 && page > 0) setPage(page - 1);
      else setData(res);
    } catch (e) {
      setErr(errorMessage(e, "Could not load users"));
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => {
    load();
  }, [load]);

  const done = (message) => {
    setRoleUser(null);
    setDeleteUser(null);
    setErr("");
    setOk(message);
    load();
  };
  const failed = (message) => {
    setRoleUser(null);
    setDeleteUser(null);
    setOk("");
    setErr(message);
  };

  const [title, subtitle] = TITLES[mode];
  const cols = mode === "view" ? 4 : 5;

  return (
    <>
      <div className="heading">
        <div>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
      </div>
      <Feedback error={err} success={ok} />
      <div className="panel">
        <div className="panel-head">
          <b>Registered users</b>
        </div>
        <div className="table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th style={{ width: 70 }}>#</th>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                {mode !== "view" && <th>Action</th>}
              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr><td colSpan={cols} className="text-center py-4"><span className="spinner-border spinner-border-sm" /></td></tr>
              )}
              {!loading && data.content.map((u, i) => {
                const inactive = u.userState === "Deactivated";
                return (
                  <tr key={u.id}>
                    <td>{page * PAGE_SIZE + i + 1}</td>
                    <td>{u.username}</td>
                    <td>{u.role}</td>
                    <td><Status value={u.userState} /></td>
                    {mode === "role" && (
                      <td>
                        <button className="btn btn-sm btn-outline-primary" disabled={inactive} onClick={() => setRoleUser(u)}>
                          <i className="bi bi-pencil-square me-1" />Edit
                        </button>
                      </td>
                    )}
                    {mode === "delete" && (
                      <td>
                        <button className="btn btn-sm btn-outline-danger" disabled={inactive} onClick={() => setDeleteUser(u)}>
                          <i className="bi bi-trash me-1" />Delete
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!loading && !data.content.length && <p className="empty">No users found.</p>}
        </div>
        <Pager page={page} size={PAGE_SIZE} count={data.content.length} totalPages={data.totalPages} totalElements={data.totalElements} noun="users" onChange={setPage} />
      </div>
      {roleUser && <ChangeRoleModal user={roleUser} onClose={() => setRoleUser(null)} onDone={done} onError={failed} />}
      {deleteUser && <DeleteUserModal user={deleteUser} onClose={() => setDeleteUser(null)} onDone={done} onError={failed} />}
    </>
  );
}
