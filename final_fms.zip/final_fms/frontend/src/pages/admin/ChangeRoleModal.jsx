import { useState } from "react";
import Modal from "../../components/Modal.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import { adminApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";

const ALL_ROLES = ["ADMIN", "OPERATOR", "MANAGER"];

export default function ChangeRoleModal({ user, onClose, onDone, onError }) {
  const options = ALL_ROLES.filter((r) => r !== user.role);
  const [role, setRole] = useState(options[0]);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  async function apply() {
    setBusy(true);
    try {
      const res = await adminApi.changeRole(user.username, role);
      onDone(res.message);
    } catch (err) {
      onError(errorMessage(err, "Could not update the user"));
    }
  }

  if (confirming) {
    return (
      <ConfirmModal
        title="Confirm role change"
        message={`Are you sure you want to change the role of ${user.username} from ${user.role} to ${role}?`}
        busy={busy}
        onConfirm={apply}
        onCancel={onClose}
      />
    );
  }
  return (
    <Modal
      title={`Change role of ${user.username}`}
      onClose={onClose}
      footer={
        <>
          <button className="btn btn-outline-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={() => setConfirming(true)}>Change</button>
        </>
      }
    >
      <p className="mb-2">Current role: <span className="badge text-bg-secondary">{user.role}</span></p>
      <label className="form-label">New role</label>
      {options.map((r) => (
        <div className="form-check" key={r}>
          <input className="form-check-input" type="radio" name="new-role" id={`role-${r}`} checked={role === r} onChange={() => setRole(r)} />
          <label className="form-check-label" htmlFor={`role-${r}`}>{r}</label>
        </div>
      ))}
    </Modal>
  );
}
