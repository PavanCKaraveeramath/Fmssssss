import { useState } from "react";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import { adminApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";

export default function DeleteUserModal({ user, onClose, onDone, onError }) {
  const [busy, setBusy] = useState(false);

  async function remove() {
    setBusy(true);
    try {
      const res = await adminApi.deleteUser(user.id);
      onDone(res.message);
    } catch (err) {
      onError(errorMessage(err, "Could not delete the user"));
    }
  }

  return (
    <ConfirmModal
      title="Delete user"
      message={`Are you sure to delete ${user.username}?`}
      variant="danger"
      busy={busy}
      onConfirm={remove}
      onCancel={onClose}
    />
  );
}
