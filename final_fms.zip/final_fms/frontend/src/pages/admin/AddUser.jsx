import { useState } from "react";
import { useNavigate } from "react-router-dom";
import StrengthMeter from "../../components/StrengthMeter.jsx";
import Feedback from "../../components/Feedback.jsx";
import { adminApi } from "../../services/api.js";
import { errorMessage } from "../../services/http.js";
import { evaluatePassword, PASSWORD_ERROR } from "../../utils/passwordPolicy.js";
import { SECURITY_QUESTIONS } from "../../utils/securityQuestions.js";

const ROLES = ["ADMIN", "OPERATOR", "MANAGER"];
const MANDATORY = "THIS FIELD IS MANDATORY";

export default function AddUser() {
  const nav = useNavigate();
  const [f, setF] = useState({ username: "", password: "", confirm: "", role: "", securityQuestion: "", securityAnswer: "" });
  const [errors, setErrors] = useState({});
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (e) => setF({ ...f, [e.target.name]: e.target.value });
  const cls = (name) => `form-control ${errors[name] ? "is-invalid" : ""}`;

  function validate() {
    const e = {};
    if (!f.username.trim()) e.username = MANDATORY;
    if (!evaluatePassword(f.password).accepted) e.password = PASSWORD_ERROR;
    if (f.confirm !== f.password) e.confirm = "Password doesn't match";
    if (!f.role) e.role = MANDATORY;
    if (!f.securityQuestion) e.securityQuestion = MANDATORY;
    if (!f.securityAnswer.trim()) e.securityAnswer = MANDATORY;
    return e;
  }

  async function go(ev) {
    ev.preventDefault();
    setErr("");
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const res = await adminApi.addUser({
        username: f.username.trim(),
        password: f.password,
        role: f.role,
        securityQuestion: f.securityQuestion,
        securityAnswer: f.securityAnswer.trim(),
      });
      nav("/admin/users", { state: { ok: res.message } });
    } catch (error) {
      const msg = errorMessage(error, "Could not add user");
      if (error.response?.status === 409) setErrors({ username: msg });
      else if (msg === PASSWORD_ERROR) setErrors({ password: msg });
      else setErr(msg);
      setBusy(false);
    }
  }

  return (
    <>
      <div className="heading">
        <div>
          <h1>Add user</h1>
          <p>Create an account and assign its role.</p>
        </div>
      </div>
      <Feedback error={err} />
      <div className="panel p-4" style={{ maxWidth: 640 }}>
        <form onSubmit={go} noValidate>
          <div className="mb-3">
            <label className="form-label">Username</label>
            <input name="username" className={cls("username")} value={f.username} onChange={set} autoComplete="off" />
            {errors.username && <div className="invalid-feedback">{errors.username}</div>}
          </div>
          <div className="mb-3">
            <label className="form-label">Password</label>
            <input name="password" type="password" className={cls("password")} value={f.password} onChange={set} autoComplete="new-password" />
            {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            <StrengthMeter password={f.password} />
          </div>
          <div className="mb-3">
            <label className="form-label">Confirm password</label>
            <input name="confirm" type="password" className={cls("confirm")} value={f.confirm} onChange={set} autoComplete="new-password" />
            {(errors.confirm || (f.confirm && f.confirm !== f.password)) && (
              <div className="invalid-feedback d-block">Password doesn&apos;t match</div>
            )}
          </div>
          <div className="mb-3">
            <label className="form-label">Role</label>
            <select name="role" className={`form-select ${errors.role ? "is-invalid" : ""}`} value={f.role} onChange={set}>
              <option value="">Choose role</option>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
            {errors.role && <div className="invalid-feedback">{errors.role}</div>}
          </div>
          <div className="mb-3">
            <label className="form-label">Security question</label>
            <select name="securityQuestion" className={`form-select ${errors.securityQuestion ? "is-invalid" : ""}`} value={f.securityQuestion} onChange={set}>
              <option value="">Choose a security question</option>
              {SECURITY_QUESTIONS.map((q) => <option key={q}>{q}</option>)}
            </select>
            {errors.securityQuestion && <div className="invalid-feedback">{errors.securityQuestion}</div>}
          </div>
          <div className="mb-4">
            <label className="form-label">Answer</label>
            <input name="securityAnswer" className={cls("securityAnswer")} value={f.securityAnswer} onChange={set} autoComplete="off" />
            {errors.securityAnswer && <div className="invalid-feedback">{errors.securityAnswer}</div>}
          </div>
          <button className="btn btn-primary" disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2" />}Add user
          </button>
        </form>
      </div>
    </>
  );
}
