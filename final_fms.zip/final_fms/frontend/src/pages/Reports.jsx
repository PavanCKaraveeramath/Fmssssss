import { useEffect, useState } from "react";
import { ArcElement, BarElement, CategoryScale, Chart as ChartJS, Legend, LinearScale, Tooltip } from "chart.js";
import { Bar, Doughnut } from "react-chartjs-2";
import Feedback from "../components/Feedback.jsx";
import { reportApi } from "../services/api.js";
import { errorMessage } from "../services/http.js";
import { SEVERITY_COLORS, STATUS_COLORS } from "../utils/format.js";

ChartJS.register(ArcElement, BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const CATEGORIES = {
  severity: { label: "Severity Distribution", load: reportApi.bySeverity, colors: SEVERITY_COLORS, column: "Severity" },
  status: { label: "Status Distribution", load: reportApi.byStatus, colors: STATUS_COLORS, column: "Status" },
};

export default function Reports() {
  const [category, setCategory] = useState("severity");
  const [report, setReport] = useState(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setErr("");
    CATEGORIES[category]
      .load()
      .then((r) => !cancelled && setReport(r))
      .catch((e) => !cancelled && setErr(errorMessage(e, "Could not load the report")))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [category]);

  const cfg = CATEGORIES[category];
  const labels = report ? Object.keys(report.counts) : [];
  const values = report ? Object.values(report.counts) : [];
  const chartData = { labels, datasets: [{ label: "Faults", data: values, backgroundColor: labels.map((l) => cfg.colors[l]), borderWidth: 1 }] };

  return (
    <>
      <div className="heading">
        <div>
          <h1>Reports</h1>
          <p>Graphical summary of all recorded faults.</p>
        </div>
      </div>
      <Feedback error={err} />
      <div className="panel p-3">
        <div className="d-flex flex-wrap align-items-center gap-3 mb-3">
          <label htmlFor="report-category" className="fw-semibold mb-0">Category</label>
          <select id="report-category" className="form-select w-auto" value={category} onChange={(e) => setCategory(e.target.value)}>
            {Object.entries(CATEGORIES).map(([key, c]) => (
              <option key={key} value={key}>{c.label}</option>
            ))}
          </select>
          {report && <span className="text-muted">Total faults: <strong>{report.total}</strong></span>}
        </div>

        {loading && <div className="text-center py-5"><span className="spinner-border" /></div>}

        {!loading && report && (report.total === 0 ? (
          <p className="empty">No faults recorded yet. The simulator creates new alarms every minute.</p>
        ) : (
          <div className="row g-4">
            <div className="col-lg-7">
              <div className="chart-box">
                <Bar
                  data={chartData}
                  options={{ maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }}
                />
              </div>
            </div>
            <div className="col-lg-5">
              <div className="chart-box">
                <Doughnut data={chartData} options={{ maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }} />
              </div>
            </div>
            <div className="col-12">
              <table className="table table-sm w-auto mb-0">
                <thead>
                  <tr><th>{cfg.column}</th><th>Count</th></tr>
                </thead>
                <tbody>
                  {labels.map((l) => (
                    <tr key={l}>
                      <td><i className="swatch" style={{ background: cfg.colors[l] }} />{l}</td>
                      <td>{report.counts[l]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
