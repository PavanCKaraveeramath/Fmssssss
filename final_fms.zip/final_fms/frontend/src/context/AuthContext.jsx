import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { authApi } from "../services/api.js";
import { clearSession, readSession, writeSession } from "../services/session.js";

const AuthContext = createContext(null);

export const HOME_BY_ROLE = {
  ADMIN: "/admin/users",
  OPERATOR: "/operator/devices",
  MANAGER: "/manager/faults",
};

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(readSession);
  const navigate = useNavigate();

  const login = useCallback(async (username, password) => {
    const data = await authApi.login(username, password);
    const session = { token: data.token, username: data.username, role: data.role };
    writeSession(session);
    setAuth(session);
    return data;
  }, []);

  const logout = useCallback(
    (message = "Successfully logged out.", type = "success") => {
      clearSession();
      setAuth(null);
      navigate("/login", { replace: true, state: { message, type, loggedOut: true } });
    },
    [navigate],
  );

  useEffect(() => {
    const onUnauthorized = () => {
      if (readSession()) logout("Session expired, please login again", "warning");
    };
    window.addEventListener("fm:unauthorized", onUnauthorized);
    return () => window.removeEventListener("fm:unauthorized", onUnauthorized);
  }, [logout]);

  const value = useMemo(
    () => ({ user: auth ? { username: auth.username, role: auth.role } : null, login, logout }),
    [auth, login, logout],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
