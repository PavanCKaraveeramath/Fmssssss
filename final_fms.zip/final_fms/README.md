# Fault Management System

Enterprise-grade Fault Management Dashboard for monitoring network device alarms, managing users and devices, and generating operational reports.

**Capstone Project** · Full-stack application with role-based access control, real-time SNMP trap simulation, and automated alarm ingestion.

---

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Tech Stack](#tech-stack)
- [Features](#features)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Demo Accounts](#demo-accounts)
- [API Testing](#api-testing)
- [Role Capabilities](#role-capabilities)
- [Project Structure](#project-structure)
- [Development Notes](#development-notes)
- [Troubleshooting](#troubleshooting)
- [License](#license)

---

## Overview

The Fault Management System provides a complete lifecycle for network fault handling:

1. **Device Management** – Register and maintain network devices (routers, switches).
2. **Alarm Ingestion** – Simulated Cisco BGP SNMP traps are generated as XML files and ingested into the system.
3. **Fault Operations** – Acknowledge, clear, terminate, and annotate alarms.
4. **User Administration** – Role-based user lifecycle with secure authentication.
5. **Reporting** – Dashboard charts and counts for operational visibility.

Roles are strictly enforced: **ADMIN**, **OPERATOR**, and **MANAGER**.

---

## Architecture

```
┌─────────────────┐     JWT + REST      ┌──────────────────────────────┐
│  React Frontend │ ◄─────────────────► │  Spring Boot 3 Backend       │
│  (Vite + React) │   http://localhost  │  • Security (JWT + BCrypt)   │
│  Port 5173      │         :8080       │  • JPA / MySQL               │
└─────────────────┘                     │  • Trap Simulator            │
                                        │  • Alarm Ingestion Service   │
                                        └──────────────┬───────────────┘
                                                       │
                                                       ▼
                                              ┌─────────────────┐
                                              │  MySQL 8        │
                                              │  fault_mgmt DB  │
                                              └─────────────────┘
```

**Data flow for alarms**

1. `TrapSimulator` writes one XML trap file per active device every 60 seconds into `backend/fm-data/input/`.
2. `AlarmIngestionService` polls every 15 seconds, parses the XML, persists alarms with status `OPEN`, and moves files to `fm-data/processed/`.

---

## Tech Stack

| Layer        | Technology                                      |
|--------------|-------------------------------------------------|
| Backend      | Java 25, Spring Boot 3.5, Spring Security, Spring Data JPA |
| Security     | JWT (JJWT 0.12), BCrypt password hashing        |
| Database     | MySQL 8.0+                                      |
| Frontend     | React 19, Vite 6, React Router 7, Bootstrap 5, Chart.js |
| API Testing  | Postman / Newman collection (84 requests)       |
| Logging      | Log4j2                                          |
| Build        | Maven 3.9+, npm                                 |

---

## Features

### Authentication & Security
- JWT-based stateless authentication (30-minute expiry)
- BCrypt password hashing
- Password policy enforcement
- Security questions for password recovery
- CAPTCHA-protected password change
- Role-based route guards (frontend + backend)

### Admin
- User listing with pagination (10 per page)
- Create user with security question
- Change user role
- Soft-delete (deactivate) users

### Operator
- Device inventory (serial, IP, type, state)
- Add / edit / deactivate devices
- IP address validation (rejects invalid and reserved ranges)
- Duplicate serial / IP protection

### Manager
- Live fault table with colour-coded severity and status
- Acknowledge, Clear, Terminate operations
- Notes editing
- Search by IP, serial number, or trap name
- Auto-refresh every 30 seconds
- Reports dashboard (Chart.js)

### Cross-cutting
- Global exception handling with structured error responses
- Bean Validation with localized messages
- CORS configuration for local development
- Idempotent schema and seed data scripts

---

## Prerequisites

| Tool       | Version / Notes                          |
|------------|------------------------------------------|
| JDK        | 25 LTS                                   |
| Maven      | 3.9+                                     |
| MySQL      | 8.0.16+ running on `localhost:3306`      |
| Node.js    | 18+ (recommended 20 LTS)                 |
| Newman     | Optional – `npm i -g newman` for CLI tests |

**IDE note (Eclipse):** Install the Lombok plugin once (`java -jar lombok.jar` → select Eclipse → restart). Without it, generated getters and builders appear as errors.

---

## Quick Start

### 1. Database

Ensure MySQL is running. The application creates the database and tables automatically on first start.

Default credentials (override with environment variables):

```bash
export DB_USER=root
export DB_PASSWORD=root
```

### 2. Backend

```bash
cd backend
mvn spring-boot:run
```

- API base URL: `http://localhost:8080`
- Database `fault_management_dashboard` and tables are created from `schema.sql` / `data.sql`.
- Trap simulator starts after a 5-second delay and generates one XML file per minute per active device.
- Ingestion service processes files every 15 seconds.

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**.

### 4. Verify

Wait approximately 1–2 minutes after backend start so that OPEN alarms exist, then log in with one of the demo accounts.

---

## Configuration

Key settings live in `backend/src/main/resources/application.properties`:

| Property                        | Default                                      | Description                          |
|---------------------------------|----------------------------------------------|--------------------------------------|
| `server.port`                   | `8080`                                       | Backend port                         |
| `spring.datasource.url`         | `jdbc:mysql://localhost:3306/fault_management_dashboard` | JDBC URL                    |
| `spring.datasource.username`    | `root`                                       | DB user (`DB_USER` env override)     |
| `spring.datasource.password`    | (see properties)                             | DB password (`DB_PASSWORD` env)      |
| `fm.jwt.secret`                 | (dev secret)                                 | JWT signing key (`JWT_SECRET` env)   |
| `fm.jwt.expiration-ms`          | `1800000` (30 min)                           | Token lifetime                       |
| `fm.cors.allowed-origins`       | `http://localhost:5173,...`                  | Allowed frontend origins             |
| `fm.simulator.interval-ms`      | `60000`                                      | Trap generation interval             |
| `fm.ingestion.poll-interval-ms` | `15000`                                      | Ingestion poll interval              |

**Production recommendation:** Always override `JWT_SECRET`, `DB_USER`, and `DB_PASSWORD` via environment variables. Never commit real secrets.

---

## Demo Accounts

| Username  | Password      | Role     | Security Answer |
|-----------|---------------|----------|-----------------|
| `admin`   | `Admin123!`   | ADMIN    | blue            |
| `operator`| `Operator123!`| OPERATOR | atlas           |
| `manager` | `Manager123!` | MANAGER  | rose            |

**Seed devices**

| Serial | IP        | Type   |
|--------|-----------|--------|
| RT123  | 10.0.0.1  | Router |
| NS156  | 10.0.0.2  | Switch |

---

## API Testing

A comprehensive Postman collection is provided under `postman/`.

```bash
cd postman
newman run FaultManagement.postman_collection.json \
  -e local.postman_environment.json
```

Alternatively, import both JSON files into the Postman desktop app and run the collection.

> **Tip:** Wait ~2 minutes after backend start so that multiple OPEN alarms exist before running the full suite.

---

## Role Capabilities

| Capability                  | ADMIN | OPERATOR | MANAGER |
|-----------------------------|:-----:|:--------:|:-------:|
| User management             |  ✓    |          |         |
| Device management           |       |    ✓     |         |
| View / act on faults        |       |          |    ✓    |
| View reports                |  ✓    |    ✓     |    ✓    |
| Change own password         |  ✓    |    ✓     |    ✓    |
| Forgot-password flow        |  ✓    |    ✓     |    ✓    |

---

## Project Structure

```
fault-management-system/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/faultmanagement/
│       │   ├── api/              # REST controllers
│       │   ├── dto/              # Request/response objects
│       │   ├── entity/           # JPA entities
│       │   ├── exception/        # Domain exceptions
│       │   ├── repository/       # Spring Data repositories
│       │   ├── security/         # JWT filter, SecurityConfig
│       │   ├── service/          # Business logic
│       │   ├── simulator/        # SNMP trap XML generator
│       │   └── utility/          # Validation, helpers, AOP
│       └── resources/
│           ├── application.properties
│           ├── schema.sql
│           ├── data.sql
│           ├── log4j2-spring.properties
│           └── ValidationMessages.properties
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── components/           # Shared UI (Modal, Captcha, Pager…)
│       ├── context/              # AuthContext
│       ├── pages/                # Login, Admin, Operator, Manager views
│       ├── routes/               # Route guards
│       ├── services/             # HTTP client & API layer
│       └── utils/                # Validators, helpers
├── postman/
│   ├── FaultManagement.postman_collection.json
│   └── local.postman_environment.json
└── README.md
```

---

## Development Notes

1. **Password on user creation** – The frontend requires a password that satisfies the backend password policy (length, complexity). The original PDF suggestion of setting the password equal to the username is intentionally not followed.
2. **Security questions** – The three questions seeded in `data.sql` match the dropdown in the frontend (`frontend/src/utils/securityQuestions.js`).
3. **Duplicate username** – Returns HTTP 409; the frontend surfaces the error inline on the username field.
4. **Reports** – Available to all three roles via a dedicated Report tab.
5. **Alarm colours** – Severity and status drive row colouring on the Manager faults table as specified in the product requirements.
6. **Soft delete** – Users are marked `Deactivated` rather than physically removed; they can no longer authenticate.

---

## Troubleshooting

| Symptom                                      | Resolution                                                                 |
|----------------------------------------------|----------------------------------------------------------------------------|
| `Access denied for user 'root'`              | Set `DB_USER` / `DB_PASSWORD` environment variables                        |
| Frontend: “Cannot reach the server”          | Ensure backend is running; verify origin is listed in `fm.cors.allowed-origins` |
| No faults appear                             | Wait 1–2 minutes; confirm at least one device is in `Activated` state      |
| Eclipse shows red markers on getters/builders| Install Lombok into Eclipse and restart                                    |
| Port 8080 already in use                     | Change `server.port` or stop the conflicting process                       |
| JWT signature errors after restart           | Ensure the same `JWT_SECRET` is used across restarts                       |

---

## License

This project is submitted as a Capstone deliverable. All rights reserved by the project authors.

---

*Built with Spring Boot 3 · React 19 · MySQL 8*
